<template>
  <div>
    <el-form :rules="rules" class="loginContainer">
      <h3 class="loginTitle">
        系统登录
      </h3>
      <el-form-item prop="username">
        <el-input type="text" v-model="user.sn" placeholder="请输入用户名" >
        </el-input>
      </el-form-item>
      <el-form-item prop="password">
        <el-input type="password" v-model="user.password" placeholder="请输入密码" >
        </el-input>
      </el-form-item>

<!--      <el-checkbox v-model="checked" class="loginRemember">记住我</el-checkbox>-->
      <el-button type="primary" style="width:100%" @click="submitLogin">登录</el-button>
    </el-form>
  </div>
</template>

<script>
import {userLogin} from '../../api/user'
import store from '../../store'

export default {
  name: 'Login',
  data () {
    return {
      user: {
        sn: '',
        password: ''
      }
    }
  },
  methods: {
    submitLogin () {
      // user输入框进行双向绑定后，用于发请求时作为参数传递给后端
      userLogin(this.user).then(res => {
        // 此处的res已经封装了
        console.info(res)
        // 对返回的res信息进行不同的处理
        if (res.data === null) {
          this.$message({
            showClose: true,
            message: '用户名或密码错误，请重新输入',
            type: 'warning'
          })
        } else {
          this.$message({
            showClose: true,
            message: '登录成功',
            type: 'success'
          })
          //  跳转到登录成功的页面
          this.$router.push({path: '/main'})
        }
      })
    }
  },
  created () {
    store.dispatch('user/clearUserInfo')
  }
}
</script>

<style>
.loginContainer{
  border-radius: 15px;
  background-clip: padding-box;
  margin: 180px auto;
  width: 350px;
  padding: 15px 35px 15px 35px;
  background: #021725;
  border:1px solid whitesmoke;
  box-shadow: 0 0 25px snow;
}
.loginTitle{
  margin: 0px auto 48px auto;
  text-align: center;
  font-size: 40px;
  color: white;
}
.loginRemember{
  text-align: left;
  margin: 0px 0px 15px 0px;
}
body{
  background-image: url('https://ts1.cn.mm.bing.net/th/id/R-C.4b599bda273754ce08695b7068201471?rik=bO1Fc47%2fmWFkcA&riu=http%3a%2f%2fwww.shijuepi.com%2fuploads%2fallimg%2f201221%2f1-201221141F6.gif&ehk=i3LUj2Lhk%2bCBufFLhqqHXnxJSG%2bCghKu9jvc7B7ZmJA%3d&risl=&pid=ImgRaw&r=0') ;
  background-size:100%;
  background-repeat: no-repeat;
}
</style>
