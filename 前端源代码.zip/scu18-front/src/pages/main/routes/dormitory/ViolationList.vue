<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/violationList' }">寝室违纪情况</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <el-form :inline="true" :model="searchData" class="demo-form-inline"  label-width="80px">
                <el-form-item label="园区">
                    <el-select v-model="searchData.campus" placeholder="园区">
                        <el-option label="全部" value=""></el-option>
                        <el-option label="西园" value="西园"></el-option>
                        <el-option label="东园" value="东园"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="楼栋">
                    <el-select v-model="searchData.building" placeholder="楼栋">
                        <el-option label="全部" value=""></el-option>
                        <el-option label="1栋" value="1栋"></el-option>
                        <el-option label="2栋" value="1栋"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="房间号">
                    <el-input v-model="searchData.roomNumber" placeholder="房间号">
                    </el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onQuery">查询</el-button>
                </el-form-item>
            </el-form>
            <el-table
                    :data="showData"
                    style="width: 100%">
                <el-table-column
                        prop="campus"
                        label="园区"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="building"
                        label="楼栋"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="roomNumber"
                        label="房间号"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="content"
                        label="违规内容"
                        width="250">
                </el-table-column>
                <el-table-column
                        prop="punishment"
                        label="违规处理"
                        width="250">
                </el-table-column>
                <el-table-column
                        prop="createTime"
                        label="记录时间">
                </el-table-column>
            </el-table>

            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="pageNo"
                    :page-size="pageSize"
                    :page-sizes="[5, 10, 20, 50]"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
            </el-pagination>

        </el-card>
    </div>
</template>

<script>
import {pageList} from '@api/violate'
import {getById} from '@api/apartment'
import {mapGetters} from 'vuex'
export default {
  name: 'Violation',
  computed: {
    ...mapGetters({
      userSn: 'user/getUserSn',
      userType: 'user/getUserType'
    })
  },
  data () {
    return {
      total: 0,
      pageNo: 1,
      pageSize: 5,
      violateData: [],
      showData: [],
      searchData: []
    }
  },
  methods: {
    async getViolateList () {
      let obj = {
        sn: this.userSn,
        roleType: this.userType,
        pageNo: this.pageNo,
        pageSize: this.pageSize
      }
      let res = await pageList(obj)
      this.violateData = res.data.records
      this.total = res.data.total
      this.violateData.forEach(function (value, index, array) {
        getById({roomId: array[index].id}).then(res => {
          array[index]['campus'] = res.data.campus
          array[index]['building'] = res.data.building
          array[index]['roomNumber'] = res.data.roomNumber
        })
      })
      this.showData = this.violateData
    },
    // 查询
    onQuery () {
      this.showData = this.violateData.filter(function (value, index, array) {
        return (this.like(array[index].campus, this.searchData.campus) &&
            this.like(array[index].building, this.searchData.building) &&
            this.like(array[index].roomNumber, this.searchData.roomNumber))
      })
    },
    // js 模糊匹配
    like (str1, str2) {
      let result = str2.indexOf(str1)
      if (result < 0) {
        return false
      } else {
        return true
      }
    },
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.queryAparts()
    },
    handleCurrentChange (value) {
      console.log(value)
      this.searchData.pageNo = value
      this.queryAparts()
    }
  },
  created () {
    this.getViolateList()
  }
}
</script>

<style scoped>

</style>
