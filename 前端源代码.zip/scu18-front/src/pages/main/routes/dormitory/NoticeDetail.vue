<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/noticeDetail' }">公告详情</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <div>
                <el-row :gutter="20" style="margin-top:10px;">
<!--                    <el-col :span="32">-->
                        <div >
                            <el-card class="box-card">
                                <div slot="header" class="clearfix" style="text-align:center;">
                                    <h2>{{noticeData.title}}</h2>
                                    <ul><span>
                                            <font color="#808080">日期：{{noticeData.createTime}}</font>
                                        </span><span style="margin-left: 60px;">
                                            <font color="#808080">发布人：{{name}}</font>
                                        </span></ul>
                                </div>
                                <div>
                                    <p>
                                        {{noticeData.content}}
                                    </p>
                                </div>
                            </el-card>
                        </div>
<!--                    </el-col>-->
                </el-row>
            </div>
        </el-card>
    </div>
</template>

<script>
import { getContent } from '@api/notice'
import {selectNameBySn} from '@api/user'
import moment from 'moment'
export default {
  name: 'NoticeDetail',
  data () {
    return {
      noticeData: {},
      name: ''
    }
  },
  methods: {
    getContent () {
      getContent(this.$route.query).then(res => {
        this.noticeData = res.data
        this.noticeData.createTime = moment(this.noticeData.createTime).format('YYYY-MM-DD hh:mm:ss')
        selectNameBySn({sn: res.data.houseparentSn}).then(res => {
          this.name = res.data[0].name
        })
      })
    }
  },
  created () {
    this.getContent()
  }
}
</script>

<style scoped>
/* 卡片样式 */
.text {
    font-size: 14px;
}

.item {
    margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
    display: table;
    content: "";
}

.clearfix:after {
    clear: both
}

.box-card {
    width: 100%;
}

/* 文本样式区 */
.name-role {
    font-size: 16px;
    padding: 5px;
    text-align: center;
}

.sender {
    text-align: center;
}

.time-info {
    text-align: center;
    padding-top: 10px;
}

.personal-relation {
    font-size: 16px;
    padding: 0px 5px 15px;
    margin-right: 1px;
    width: 100%
}

.relation-item {
    padding: 12px;

}

.dialog-footer {
    padding-top: 10px;
    padding-left: 10%;
}

/* 布局样式区 */
.el-row {
    margin-bottom: 20px;
}

.el-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>
