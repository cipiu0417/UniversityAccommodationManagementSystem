<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/violationManage' }">违纪管理</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <el-form :inline="true" :model="searchData" class="demo-form-inline"  label-width="80px">
                <el-form-item label="园区">
                    <el-select v-model="searchData.campus" placeholder="园区">
                        <el-option label="全部" value=""></el-option>
                        <el-option label="西园" value="西园"></el-option>
                        <el-option label="东园" value="东园"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="楼栋">
                    <el-select v-model="searchData.building" placeholder="楼栋">
                        <el-option label="全部" value=""></el-option>
                        <el-option label="1栋" value="1栋"></el-option>
                        <el-option label="2栋" value="1栋"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="房间号">
                    <el-input v-model="searchData.roomNumber" placeholder="房间号">
                    </el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onQuery">查询</el-button>
                </el-form-item>
            </el-form>
            <el-table
                    :data="roomData"
                    style="width: 100%">
                <el-table-column
                        prop="campus"
                        label="园区"
                        width="100">
                </el-table-column>
                <el-table-column
                        prop="building"
                        label="楼栋"
                        width="100">
                </el-table-column>
                <el-table-column
                        prop="roomNumber"
                        label="房间号">
                </el-table-column>
                <el-table-column
                        prop="gender"
                        label="男女寝">
                </el-table-column>
                <el-table-column
                        prop="houseparent"
                        label="宿舍管理员">
                </el-table-column>
                <el-table-column
                        label="操作">
                    <template slot-scope="scope">
                        <el-button link type="text" size="small" @click="handleEdit(scope.row)"
                        >违纪处理
                        </el-button>
                        <el-button link type="text" size="small" @click="onHistory(scope.row)"
                        >查看记录
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>

            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="searchData.pageNo"
                    :page-size="searchData.pageSize"
                    :page-sizes="[5, 10, 20, 50]"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
            </el-pagination>

            <el-dialog
                    title="违纪处理"
                    :visible.sync="showEdit"
                    width="60%"
                    :before-close="handleClose">
                <template>
                    <el-table
                            :data="room"
                            style="width: 100%">
                        <el-table-column label="当前宿舍" style="width: 100%">
                            <el-table-column
                                    prop="campus"
                                    label="园区">
                            </el-table-column>
                            <el-table-column
                                    prop="building"
                                    label="楼栋">
                            </el-table-column>
                            <el-table-column
                                    prop="roomNumber"
                                    label="房间号">
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                </template>
                <span>
                <el-form :model="violateData" ref="violateData" label-width="80px" style="margin-top: 40px">
                    <el-form-item
                            label="违纪情况"
                            prop="content"
                            :rules="[{ required: true, message: '请填写违纪情况'}]">
                        <el-input v-model="violateData.content"></el-input>
                    </el-form-item>
                    <el-form-item
                            label="违纪处罚"
                            prop="punishment"
                            :rules="[{ required: true, message: '请填写违纪处罚'}]">
                        <el-input v-model="violateData.punishment"></el-input>
                    </el-form-item>
                </el-form>
            </span>
                <span slot="footer" class="dialog-footer">
                <el-button @click="showEdit = false">取 消</el-button>
                <el-button type="primary" @click="editConfirm('violateData')">确 定</el-button>
            </span>
            </el-dialog>

            <!-- 查看违纪历史-->
            <div>
                <el-drawer title="申请历史记录" :visible.sync="showHistory" :with-header="false">
                    <div class="block">
                        <el-timeline>
                            <el-timeline-item :timestamp="item.createTime" placement="top"
                                              v-for="(item, index) in this.curHistory">
                                <el-card>
                                    <h4>房间号：{{item.roomId}}</h4>
                                    <p>违纪内容：{{item.content}}</p>
                                    <p>违纪处理：{{item.punishment}}</p>
                                    <p>处理人：{{item.houseparentSn}}</p>
                                </el-card>
                            </el-timeline-item>
                        </el-timeline>
                    </div>
                </el-drawer>
            </div>
        </el-card>
    </div>
</template>

<script>
import {queryApartment} from '@api/apartment'
import {selectNameBySn} from '@api/user'
import {violateRecordInsert, violateRecordSelectByRoomId} from '@api/violate'
import {mapGetters} from 'vuex'
export default {
  name: 'ViolationManage',
  computed: {
    ...mapGetters({
      userSn: 'user/getUserSn'
    })
  },
  data () {
    return {
      showHistory: false,
      showEdit: false,
      roomData: [],
      room: [{
        content: '',
        punishment: ''
      }],
      violateData: {},
      searchData: {
        campus: '',
        building: '',
        gender: '',
        pageNo: 1,
        pageSize: 5
      },
      curHistory: []
    }
  },
  mounted () {
    this.getList()
  },
  methods: {
    getList () {
      queryApartment(this.searchData).then(res => {
        this.roomData = res.data.records
        this.roomData.forEach(function (value, index, array) {
          selectNameBySn({sn: array[index].houseparentSn}).then(res => {
            array[index]['houseparent'] = res.data[0].name
          })
        })
        console.log(this.roomData)
      })
    },
    onQuery () {
      this.getList()
    },
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.getList()
    },
    handleCurrentChange (value) {
      console.log(value)
      this.searchData.pageNo = value
      this.getList()
    },
    handleEdit (row) {
      this.showEdit = true
      this.room = []
      this.room.push(row)
    },
    editConfirm (violateForm) {
      this.$refs[violateForm].validate((valid) => {
        if (valid) {
          let obj = {
            content: this.violateData.content,
            punishment: this.violateData.punishment,
            roomId: this.room[0].id
          }
          let obj1 = {
            houseparentSn: this.userSn
          }
          Object.assign(obj, obj1)
          violateRecordInsert(obj).then(res => {
            this.$message({
              message: '违纪处理成功',
              type: 'success'
            })
          })
          this.showEdit = false
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    //    查看历史违纪记录
    onHistory (row) {
      this.showHistory = true
      violateRecordSelectByRoomId({roomId: row.id}).then(res => {
        this.curHistory = res.data.records
      })
    }
  }
}
</script>

<style scoped>

</style>
