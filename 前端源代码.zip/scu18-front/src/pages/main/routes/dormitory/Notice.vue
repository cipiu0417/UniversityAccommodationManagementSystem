<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/notice' }">公告通知</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <el-container>
                <el-aside width="420px">
                    <!--侧边新闻，图片显示方式有待改进-->
                    <ul style="list-style-type:none">
                        <li><h2 style="text-align: center;">❤ ❤ 寝室你我他 ❤ ❤</h2></li>
                        <li><h2 style="text-align: center;margin-bottom: 50px;">❤ ❤ 文明靠大家 ❤ ❤</h2></li>
                        <li>
                            <el-dropdown>
                                <el-button style="width:400px;margin-bottom:15px;" type="primary" plain>
                                    嗨，这是一则公告测试
                                </el-button>
                                <el-dropdown-menu slot="dropdown">
                                    <el-dropdown-item>
                                        <el-image style="width: 380px; height: 300px" :src="url1"
                                            :fit="fit"></el-image></el-dropdown-item>
                                </el-dropdown-menu>
                            </el-dropdown>
                        </li>
                        <li></li>
                        <li>
                            <el-dropdown>
                                <el-button style="width:400px;margin-bottom:15px;" type="primary" plain>
                                    Paris in the rain ☂
                                </el-button>
                                <el-dropdown-menu slot="dropdown">
                                    <el-dropdown-item>
                                        <el-image style="width: 380px; height: 300px" :src="url2"
                                            :fit="fit"></el-image></el-dropdown-item>
                                </el-dropdown-menu>
                            </el-dropdown>
                        </li>
                        <li>
                            <el-dropdown>
                                <el-button style="width:400px;margin-bottom:15px;" type="primary" plain>
                                    在南疆，路过了人间和山川
                                </el-button>
                                <el-dropdown-menu slot="dropdown">
                                    <el-dropdown-item>
                                        <el-image style="width: 380px; height: 300px" :src="url3"
                                            :fit="fit"></el-image></el-dropdown-item>
                                </el-dropdown-menu>
                            </el-dropdown>
                        </li>
                        <li>
                            <el-dropdown>
                                <el-button style="width:400px;margin-bottom:15px;" type="primary" plain>
                                    Hi Sir，请带我去海边。✌
                                </el-button>
                                <el-dropdown-menu slot="dropdown">
                                    <el-dropdown-item>
                                        <el-image style="width: 380px; height: 400px" :src="url4"
                                            :fit="fit"></el-image></el-dropdown-item>
                                </el-dropdown-menu>
                            </el-dropdown>
                        </li>

                    </ul>
                </el-aside>
                <el-main>
                    <!--公告通知-->
                        <el-form inline :model="searchData">
                            <el-form-item>
                                <el-input v-model="searchData.title" placeholder="输入标题搜索" />
                            </el-form-item>
                            <el-form-item>
                                <el-button icon="el-icon-search" circle  @click="onSearch"></el-button>
                            </el-form-item>
                        </el-form>
                    <el-table
                        :data="noticeData"
                        style="width: 100%">

                        <el-table-column label="公告标题" prop="title">
                            <template slot-scope="scope">
                                <router-link :to="{name:'noticeDetail',query:{id:scope.row.id}}">{{
                                    scope.row.title
                                }}</router-link>
                            </template>
                        </el-table-column>
                        <el-table-column label="发布人" prop="name" width="100px">
                        </el-table-column>
                        <el-table-column label="发布日期" prop="createTime" width="180px">
                        </el-table-column>
                            <el-table-column label="操作" width="120"  v-if="userType === 3">
                                <template slot-scope="scope">
                                    <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
                                </template>
                        </el-table-column>
                    </el-table>
                    <!--分页-->
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                        :current-page="searchData.pageNo" :page-size="searchData.pageSize" :page-sizes="[5, 10, 20, 50]"
                        layout="total, sizes, prev, pager, next, jumper" :total="total">
                    </el-pagination>
                </el-main>
            </el-container>
        </el-card>
    </div>
</template>

<script>
import {showList, deleteById} from '@api/notice'
import {selectNameBySn} from '@api/user'
import {mapGetters} from 'vuex'
export default {
  name: 'Notice',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType'
    })
  },
  data () {
    return {
      total: 0,
      noticeData: {},
      searchData: {
        title: '',
        pageNo: 1,
        pageSize: 5
      },
      fits: ['fill', 'contain', 'cover', 'none', 'scale-down'],
      url1: 'https://i.imgloc.com/2023/06/28/Vr6aCk.jpeg',
      url2: 'https://i.imgloc.com/2023/06/28/VrFlVX.jpeg',
      url3: 'https://i.imgloc.com/2023/06/28/VrF5Y8.jpeg',
      url4: 'https://i.imgloc.com/2023/06/28/VrFvMH.jpeg',
      search: ''
    }
  },
  created () {
    this.getList()
  },
  methods: {
    async getList () {
      // let res = await showList({})
      // this.noticeData = res.data.records
      // this.noticeData.forEach(async function (value, index, array) {
      //   let userInfo = await selectNameBySn({sn: array[index].houseparentSn})
      //   array[index]['name'] = userInfo.data[0].name
      // })
      showList(this.searchData).then(res => {
        this.noticeData = res.data.records
        this.noticeData.forEach(function (value, index, array) {
          selectNameBySn({sn: array[index].houseparentSn}).then(res => {
            array[index]['name'] = res.data[0].name
          })
        })
        console.log(this.noticeData)
      })
    },
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.getList()
    },
    handleCurrentChange (value) {
      console.log(value)
      this.searchData.pageNo = value
      this.getList()
    },
    onSearch () {
      this.getList()
    },
    handleDelete (user) {
      this.$confirm('此操作将删该公告, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        userRemoveById({id: user.id}).then(res => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.getList()
          }
        })
      })
    }
  }
}
</script>

<style scoped>
.add_btn {
    min-width: 200px;
    min-height: 30px;
}

.el-dropdown {
    vertical-align: top;
}

.el-dropdown+.el-dropdown {
    margin-left: 15px;
}

.el-icon-arrow-down {
    font-size: 12px;
}
</style>
