<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/postNotice' }">发布公告</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <!-- 设置标题公告管理 -->
            <div slot="header" class="clearfix">
                <span>添加公告</span>
            </div>
            <!-- 发布文章 -->
            <div class="article-title-container">
                <el-input size="medium" v-model="notice.title" placeholder="输入公告标题" />
                <el-button type="danger" size="medium" @click="openDialog" style="margin-left:10px">发布公告</el-button>
            </div>
            <!-- 公告内容 -->
            <mavon-editor ref="md" v-model="notice.content" style="height:calc(100vh - 260px)" />
            <!--发布公告弹出框-->
            <el-dialog :title="`发布公告：${notice.title}`" :visible.sync="showDialog" width="30%">
                <el-form label-position="left" label-width="80px">
                    <el-form-item label="公告类型">
                        <el-select v-model="notice.noticeType" placeholder="请选择公告类型">
                            <el-option label="公告" :value="0"></el-option>
                            <el-option label="通知" :value="1"></el-option>
                            <el-option label="提醒" :value="2"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="状态">
                        <el-switch v-model="notice.noticeStatus"></el-switch>
                    </el-form-item>
                </el-form>
                <span slot="footer">
                    <el-button @click="handleCancel">取 消</el-button>
                    <el-button type="primary" @click="handleSubmit">发布</el-button>
                </span>
            </el-dialog>
        </el-card>
    </div>
</template>

<script>
import { saveNotice } from '@/api/notice'
import {mapGetters} from 'vuex'
export default {
  name: 'PostNotice',
  computed: {
    ...mapGetters({
      userSn: 'user/getUserSn'
    })
  },
  data () {
    return {
      showDialog: false,
      notice: {
        title: '',
        content: '',
        noticeType: '',
        noticeStatus: true
      }
    }
  },
  methods: {
    // 打开文章信息填写框
    openDialog () {
      if (
        this.assertNotEmpty(this.notice.title, '请填写公告标题') &&
                this.assertNotEmpty(this.notice.content, '请填写公告内容')
      ) {
        this.showDialog = true
      }
    },

    assertNotEmpty (target, msg) {
      if (!target) {
        this.$message({
          message: msg,
          type: 'warning'
        })
        return false
      }
      return true
    },
    handleCancel () {
      this.showDialog = false
    },
    handleSubmit () {
      var body = {houseparentSn: this.userSn}
      Object.assign(body, this.notice)
      saveNotice(body).then((response) => {
        this.$notify({
          title: '提示',
          message: `公告《${this.notice.title}》发布成功`,
          type: 'success'
        })
        this.showDialog = false
        this.$router.replace('/main/dormitory/notice')
      })
    }
  }
}
</script>

<style scoped>
.box-card {
    width: 98%;
    margin: 1%;
}

.clearfix:before,
.clearfix:after {
    display: table;
    content: "";
}

.clearfix:after {
    clear: both
}

.clearfix span {
    font-weight: 600;
}

.article-title-container {
    display: flex;
    align-items: center;
    margin-bottom: 1.25rem;
    margin-top: 1.25rem;
}
</style>
