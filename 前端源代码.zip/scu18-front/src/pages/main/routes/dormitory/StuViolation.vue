<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/stuViolation' }">寝室违纪情况</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
                <h4 style="margin-left: 40px;">您所在的寝室的违纪记录</h4>
            <el-table
                    :data="showData"
                    style="width: 100%;margin: 0 20px">
                <el-table-column
                        prop="campus"
                        label="园区"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="building"
                        label="楼栋"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="roomNumber"
                        label="房间号"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="content"
                        label="违规内容"
                        width="250">
                </el-table-column>
                <el-table-column
                        prop="punishment"
                        label="违规处理"
                        width="250">
                </el-table-column>
                <el-table-column
                        prop="createTime"
                        label="记录时间">
                </el-table-column>
            </el-table>

            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="pageNo"
                    :page-size="pageSize"
                    :page-sizes="[5, 10, 20, 50]"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
            </el-pagination>
        </el-card>
    </div>
</template>

<script>
import {pageList} from '@api/violate'
import {getById} from '@api/apartment'
import {mapGetters} from 'vuex'
import moment from 'moment'
export default {
  name: 'StuViolation',
  computed: {
    ...mapGetters({
      userSn: 'user/getUserSn',
      userType: 'user/getUserType'
    })
  },
  data () {
    return {
      total: 0,
      pageNo: 1,
      pageSize: 5,
      violateData: [],
      showData: []
    }
  },
  methods: {
    async getViolateList () {
      let obj = {
        sn: this.userSn,
        roleType: this.userType,
        pageNo: this.pageNo,
        pageSize: this.pageSize
      }
      let res = await pageList(obj)
      this.violateData = res.data.records
      this.total = res.data.total
      this.violateData.forEach(function (value, index, array) {
        getById({roomId: array[index].id}).then(res => {
          array[index]['campus'] = res.data.campus
          array[index]['building'] = res.data.building
          array[index]['roomNumber'] = res.data.roomNumber
          array[index].createTime = moment(array[index].createTime).format('YYYY-MM-DD')
        })
      })
      this.showData = this.violateData
    },
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.queryAparts()
    },
    handleCurrentChange (value) {
      console.log(value)
      this.searchData.pageNo = value
      this.queryAparts()
    }
  },
  created () {
    this.getViolateList()
  }
}
</script>

<style scoped>

</style>
