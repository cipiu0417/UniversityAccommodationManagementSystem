<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/sanVisualization' }">卫生数据可视化</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <div class="header">
                <div class="header-left fl" id="time"></div>
                <div class="header-center fl">
                    <div class="header-title">
                        卫生数据可视化
                    </div>
                    <div class="header-img"></div>
                </div>
                <div class="header-right fl"></div>
                <div class="header-bottom fl"></div>

            </div>
            <div class="dashboard-container">

                <!-- 数据分析 -->
                <el-row :gutter="32" class="row-chart">
                    <!--柱状图-->
                    <el-col  :span="12">
                        <div class="chart-wrapper" style="width: 472px; height: 280px;">
                            <bar-chart />
                        </div>
                    </el-col>
                    <!--饼状图-->
                    <el-col :span="12">
                        <div class="chart-wrapper">
                            <pie-chart />
                        </div>
                    </el-col>
                </el-row>
                <el-row>
                    <!--折线图-->
                    <el-col :span="12">
                        <div class="chart-wrapper">
                            <line-chart />
                        </div>
                    </el-col>
                    <el-col :span="12">
                        <div class="chart-wrapper">
                            <room-line-chart :room-id="roomId" ref="child"/>
                            <el-form :inline="true" :model="searchData" class="demo-form-inline"  size="mini" >
                                <el-form-item label="园区">
                                    <el-select v-model="searchData.campus" placeholder="园区" style="width: 90px">
                                        <el-option label="全部" value=""></el-option>
                                        <el-option label="西园" value="西园"></el-option>
                                        <el-option label="东园" value="东园"></el-option>
                                    </el-select>
                                </el-form-item>
                                <el-form-item label="楼栋" >
                                    <el-select v-model="searchData.building" placeholder="楼栋" style="width: 100px">
                                        <el-option label="全部" value=""></el-option>
                                        <el-option
                                                v-for="item in buildingArr"
                                                :label="item"
                                                :value="item">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                                <el-form-item label="房间号">
                                    <el-input v-model="searchData.roomNumber" placeholder="房间号" style="width: 100px">
                                    </el-input>
                                </el-form-item>
                                <el-form-item>
                                    <el-button type="primary" @click="onQuery">查询</el-button>
                                </el-form-item>
                            </el-form>
                        </div>
                    </el-col>
                </el-row>

            </div>

        </el-card>
    </div>
</template>

<script>
import BarChart from '../../components/BarChart.vue'
import PieChart from '../../components/PieChart.vue'
import LineChart from '../../components/LineChart.vue'
import RoomLineChart from '../../components/RoomLineChart'
import {getRoomId} from '@api/apartment'

export default {
  name: 'SanVisualization',
  components: {
    BarChart,
    PieChart,
    LineChart,
    RoomLineChart
  },
  data () {
    return {
      buildingArr: ['1栋', '2栋', '3栋', '4栋', '5栋', '6栋', '7栋', '8栋', '9栋', '10栋'],
      searchData: {},
      roomId: 1,
      week: 2
    }
  },
  methods: {
    onQuery () {
      getRoomId(this.searchData).then(res => {
        this.roomId = res.data[0].id
        this.$refs.child.updateChart(this.week, this.roomId)
      })
    }
  }
}
</script>

<style scoped>
.header{
    width: 100%;
    height: 1.5rem;
    /*background: red;*/

}
.header .header-left{
    width: 25%;
    height: 1.05rem;
    color: white;
    /*    border: 1px solid green;*/
    text-align: center;
    line-height: 1.05rem;
}
.header .header-center{
    width: 50%;
    height: 1.05rem;
    /*border: 1px solid red;*/
    /*    background: url("../images/head.gif") no-repeat;
        background-size: 100% 100%;*/
    position: relative;
}
.header .header-center .header-title{
    text-align: center;
    color: #ffffff;
    font-size: .4rem;
    text-shadow: 0 0 .3rem #00d8ff;
    line-height: 1.05rem;
}
.header .header-img{
    background: url("../../../../assets/images/head.gif") no-repeat center center;
    background-size: 100%;
    height: 100%;
    width: 100%;
    position: absolute;
    top: .4rem;
}

.header .header-right{
    width: 25%;
    height: 1.05rem;
    /*border: 1px solid gold;*/
}
.header .header-bottom{
    width: calc(100% - .4rem);
    height: .16rem;
    background: url("../../../../assets/images/header.png") no-repeat;
    background-size: calc(100% - .2rem) 100%;
    padding: 0 .2rem;
    margin-left: .3rem;

}
.chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
}

.row-chart {
    margin-top: 30px;
}
</style>
