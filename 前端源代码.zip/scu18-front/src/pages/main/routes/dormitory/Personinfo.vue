<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/personinfo' }">个人通知</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <el-button type="primary" round @click="changeType">切换</el-button>
            <!--审核结果-->
            <div>
                <el-row class="info" v-for="item in showData">
                    <el-card class="box-card" >
                        <!--标题-->
                        <div slot="header" class="clearfix">
                            <h3>审核结果</h3>
                        </div>
                        <div v-if="!maintainType">
                            <el-result :icon="item.progress === '审核通过' ? 'success' : 'fail'" :title="item.type" :subTitle="item.createTime">
                                <template slot="extra">
                                    <span>你的{{item.type}}，{{item.progress}}。</span>
                                </template>
                            </el-result>
                        </div>
                        <div v-else>
                            <el-result icon="success" title="维修申请" :subTitle="item.createTime">
                                <template slot="extra">
                                    <span>你的维修申请已完成。</span>
                                </template>
                            </el-result>
                        </div>
                    </el-card>
                </el-row>
            </div>
        </el-card>
    </div>
</template>

<script>
import {getApplications} from '@api/application'
import {pageList} from '@api/maintain'
import {mapGetters} from 'vuex'
export default {
  name: 'personinfo',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType',
      userName: 'user/getUserName',
      userSn: 'user/getUserSn'
    })
  },
  data () {
    return {
      showData: [],
      maintainType: false
    }
  },
  created () {
    if (this.maintainType) this.getMaintainList()
    else this.getAccomList()
  },
  methods: {
    getAccomList () {
      getApplications({sn: this.userSn, roleType: this.userType}).then(res => {
        this.showData = res.data.records.filter(function (value, index, array) {
          return (array[index].progress !== '待审核')
        })
      })
    },
    getMaintainList () {
      pageList({sn: this.userSn, roleType: this.userType}).then(res => {
        this.showData = res.data.records.filter(function (value, index, array) {
          return (array[index].progress === '维修完成')
        })
      })
    },
    changeType () {
      this.maintainType = !this.maintainType
      if (this.maintainType) this.getMaintainList()
      else this.getAccomList()
    }
  }
}
</script>

<style scoped>
.info {
    position: relative;
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.text {
    font-size: 14px;
}

.item {
    margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
    display: table;
    content: "";
}

.clearfix:after {
    clear: both
}

.box-card {
    width: 480px;
    text-align: center;
}
</style>
