<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/dormitory' }">卫生管理</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <h2 style="text-align: center">第2周卫生管理</h2>
            <h4 style="text-align: center"></h4>
            <el-form :inline="true" :model="searchData" class="demo-form-inline"  label-width="80px">
                        <el-form-item label="园区">
                            <el-select v-model="searchData.campus" placeholder="园区">
                                <el-option label="全部" value=""></el-option>
                                <el-option label="西园" value="西园"></el-option>
                                <el-option label="东园" value="东园"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="楼栋">
                            <el-select v-model="searchData.building" placeholder="楼栋">
                                <el-option label="全部" value=""></el-option>
                                <el-option label="1栋" value="1栋"></el-option>
                                <el-option label="2栋" value="1栋"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="房间号">
                            <el-input v-model="searchData.roomNumber" placeholder="房间号">
                            </el-input>
                        </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onQuery">查询</el-button>
                </el-form-item>
            </el-form>

            <el-table
                    :data="roomData"
                    style="width: 100%">
                <el-table-column
                        prop="campus"
                        label="园区"
                        width="100">
                </el-table-column>
                <el-table-column
                        prop="building"
                        label="楼栋"
                        width="100">
                </el-table-column>
                <el-table-column
                        prop="roomNumber"
                        label="房间号">
                </el-table-column>
                <el-table-column
                        label="房间卫生"
                        prop="roomScore">
                </el-table-column>
                <el-table-column
                        label="阳台卫生"
                        prop="balconyScore">
                </el-table-column>
                <el-table-column
                        label="洗手间卫生"
                        prop="toiletScore">
                </el-table-column>
                <el-table-column
                        label="卫生总分"
                        prop="score">
                </el-table-column>
                <el-table-column
                        label="操作">
                    <template slot-scope="scope">
                        <el-button link type="text" size="small" @click="handleEdit(scope.row)"
                        >评分
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>

            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="searchData.pageNo"
                    :page-size="searchData.pageSize"
                    :page-sizes="[5, 10, 20, 50]"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
            </el-pagination>

            <el-dialog
                    title="卫生评分"
                    :visible.sync="showEdit"
                    width="60%"
                    :before-close="handleClose">
                <template>
                    <el-table
                            :data="room"
                            style="width: 100%">
                        <el-table-column label="当前宿舍" style="width: 100%">
                            <el-table-column
                                    prop="campus"
                                    label="园区">
                            </el-table-column>
                            <el-table-column
                                    prop="building"
                                    label="楼栋">
                            </el-table-column>
                            <el-table-column
                                    prop="roomNumber"
                                    label="房间号">
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                </template>
            <span>
                <el-form ref="score" label-width="80px" label-position="top" inline>
                    <el-form-item label="房间卫生">
                        <el-input v-model="score.roomScore" placeholder="0~100分" type="number"></el-input>
                    </el-form-item>
                    <el-form-item label="阳台卫生">
                        <el-input v-model="score.balconyScore" placeholder="0~100分" type="number"></el-input>
                    </el-form-item>
                    <el-form-item label="卫生间卫生">
                        <el-input v-model="score.toiletScore" placeholder="0~100分" type="number"></el-input>
                    </el-form-item>
                </el-form>
            </span>
                <span>
                总分：<el-input v-model="totalScore" readonly style="width:500px"></el-input>
                </span>
                <span slot="footer" class="dialog-footer">
                <el-button @click="showEdit = false">取 消</el-button>
                <el-button type="primary" @click="scoreConfirm">确 定</el-button>
            </span>
            </el-dialog>
        </el-card>
    </div>
</template>

<script>
import {sanitationRecordPageList, sanitationRecordInsert} from '@api/sanitation'
import {queryApartment} from '@api/apartment'
import {mapGetters} from 'vuex'
export default {
  name: 'Sanitation',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType',
      userName: 'user/getUserName',
      userSn: 'user/getUserSn'
    }),
    totalScore () {
      return parseInt(this.score.roomScore) * 0.4 + parseInt(this.score.balconyScore) * 0.3 + parseInt(this.score.toiletScore) * 0.3
    }
  },
  data () {
    return {
      showEdit: false,
      roomData: [],
      score: [],
      room: [],
      searchData: {
        campus: '',
        building: '',
        gender: '',
        pageNo: 1,
        pageSize: 5
      }
    }
  },
  created () {
    this.getList()
  },
  methods: {
    getList () {
      queryApartment(this.searchData).then(res => {
        this.roomData = res.data.records
        // this.roomData.forEach(function (value,index,array) {
        //   array[index]
        // })
        console.log(this.roomData)
      })
    },
    onQuery () {
      this.getList()
    },
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.getList()
    },
    handleCurrentChange (value) {
      console.log(value)
      this.searchData.pageNo = value
      this.getList()
    },
    handleEdit (row) {
      this.showEdit = true
      this.room = []
      this.room.push(row)
      this.score = {
        roomScore: 0,
        balconyScore: 0,
        toiletScore: 0
      }
    },
    scoreConfirm () {
      let obj = {
        peopleSn: this.userSn,
        roomId: this.room[0].id,
        score: this.totalScore
      }
      Object.assign(obj, this.score)
      sanitationRecordInsert(obj).then(res => {
        this.$message({
          type: 'success',
          message: '记录成功!'
        })
        this.showEdit = false
      })
    }
  }
}
</script>

<style scoped>

</style>
