<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/accommodation/accommodation' }">住宿管理</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <!--申请表单-->
            <div>
                <div class="wj_box">
                    <div class="index">
                        <el-progress style="margin-left: 1.4rem;" :percentage="percentage" status="success"
                          ></el-progress>
                    </div>
                    <div class="wj_img">
                        <div class="wj_count">
                            <h2 style="text-align: center">学生入住管理申请表</h2>
                            <h4 style="text-align: center">请仔细填写以下学生住宿管理申请表单，提交申请后将交由管理员进行审核，请耐心等待结果。</h4>
                            <div>
                                <el-form :model="applicationForm" :rules="rules" ref="applicationForm" label-width="100px"
                                    class="applicationForm">
                                    <el-form-item label="姓名">
                                        <el-input v-model="userName" readonly></el-input>
                                    </el-form-item>
                                    <el-form-item label="学号">
                                        <el-input v-model="userSn" readonly></el-input>
                                    </el-form-item>
                                    <el-form-item label="申请类型" prop="type">
                                        <el-select v-model="applicationForm.type" @change="() => {
                                            typeChange(applicationForm.type);
                                            applicationForm.type !== '' ? increase() : decrease()
                                        }">
                                            <el-option label="入住申请" value="入住申请"></el-option>
                                            <el-option label="换宿申请" value="换宿申请"></el-option>
                                            <el-option label="退宿申请" value="退宿申请"></el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item v-if="showCampus" label="园区:" prop="campus">
                                        <el-select v-model="applicationForm.campus"
                                            @change="applicationForm.campus !== '' ? increase() : decrease()" placeholder="请选择园区">
                                            <!--所有园区的数据导入-->
                                            <el-option label="西园" value="西园"></el-option>
                                            <el-option label="东园" value="东园"></el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item v-if="showCampus" label="楼栋:" prop="building">
                                        <el-select v-model="applicationForm.building"
                                            @change="applicationForm.building !== '' ? increase() : decrease()"
                                            placeholder="请选择楼栋">
                                            <!--所有楼栋的数据导入-->
                                            <el-option
                                                    v-for="item in buildingArr"
                                                    :label="item"
                                                    :value="item">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item v-if="showCampus" label="房间号:" prop="roomNumber">
                                        <el-input v-model="applicationForm.roomNumber"
                                            @change="applicationForm.floor !== '' ? increase() : decrease()" placeholder="请输入房间号" style="width: 200px">
                                        </el-input>
                                    </el-form-item>
                                    <el-form-item label="描述" prop="description">
                                        <el-input type="textarea" v-model="applicationForm.description"
                                            @change="applicationForm.description !== '' ? increase() : decrease()"></el-input>
                                    </el-form-item>
                                    <el-form-item>
                                        <el-button type="primary" @click="submitForm('applicationForm')">提交申请</el-button>
                                        <el-button @click="resetForm('applicationForm')">重置</el-button>
                                    </el-form-item>
                                </el-form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- 查看申请历史-->
            <div>
                <el-button @click="showHistory" type="primary" style="margin-left: 100px;">
                    查看申请历史
                </el-button>

                <el-drawer title="申请历史记录" :visible.sync="drawer" :with-header="false">
                    <div class="block">
                        <el-timeline>
                            <el-timeline-item :timestamp="item.createTime" placement="top"
                                v-for="(item) in this.myHistory">
                                <el-card>
                                    <h4>{{item.type}}</h4>
                                    <p>{{item.description}}</p>
                                    <span>{{item.progress}}</span>
                                </el-card>
                            </el-timeline-item>
                        </el-timeline>
                    </div>
                </el-drawer>
            </div>
        </el-card>
    </div>
</template>

<script>
import {saveApplication, getApplications} from '@api/application'
import {mapGetters} from 'vuex'
export default {
  name: 'Accommodation',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType',
      userName: 'user/getUserName',
      userSn: 'user/getUserSn'
    })
  },
  data () {
    return {
      buildingArr: ['1栋', '2栋', '3栋', '4栋', '5栋', '6栋', '7栋', '8栋', '9栋', '10栋'],
      count: 0,
      percentage: 0,
      applicationForm: {
        type: '',
        description: ''
      },
      showCampus: false,
      drawer: false,
      rules: {
        // college: [
        //   { required: true, message: '请输入学院名称', trigger: 'blur' }
        // ],
        type: [
          { required: true, message: '请选择申请类型', trigger: 'blur' }
        ],
        description: [
          { required: true, message: '请填写申请描述', trigger: 'blur' }
        ],
        campus: [
          { required: true, message: '请选择园区', trigger: 'change' }
        ],
        building: [
          { required: true, message: '请选择楼栋', trigger: 'change' }
        ],
        roomNumber: [
          { required: true, message: '请选择房间号', trigger: 'change' }
        ]
      },
      myHistory: []
    }
  },
  methods: {
    //  查看历史记录
    showHistory () {
      this.drawer = true
      getApplications({sn: this.userSn, roleType: this.userType}).then(res => {
        this.myHistory = res.data.records
      })
    },

    increase () {
      this.percentage += 15
      if (this.percentage > 87.5) {
        this.percentage = 100
      }
    },
    decrease () {
      this.percentage -= 15
      if (this.percentage < 0) {
        this.percentage = 0
      }
    },
    submitForm (formName) { // 提交事件
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let obj = this.applicationForm
          // if (obj.type !== '退宿申请') {
          //   obj.description = '园区:' + obj.campus + ', 楼栋:' + obj.building + ', 房间号:' + obj.roomNumber + ', 描述:' + obj.description
          // }
          Object.assign(obj, {sn: this.userSn})
          saveApplication(obj).then(res => {
            this.$message({
              type: 'success',
              message: '提交成功'
            })
            this.resetForm('applicationForm')
          })
        } else {
          this.$message({
            type: 'error',
            message: '提交失败'
          })
        }
      })
    },
    resetForm (formName) { // 重置
      this.$refs[formName].resetFields()
    },
    typeChange (selectValue) {
      console.info(selectValue)
      if (selectValue !== '退宿申请') {
        this.showCampus = true
      } else {
        this.showCampus = false
      }
    }
  }
}
</script>

<style scoped></style>
