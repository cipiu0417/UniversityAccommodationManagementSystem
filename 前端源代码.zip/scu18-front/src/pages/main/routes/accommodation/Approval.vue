<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/dormitory/dormitory' }">住宿审批</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <el-table
                    :data="applicationData"
                    stripe
                    style="width: 100%">
                <el-table-column
                        type="expand">
                    <template slot-scope="props">
                        <el-form label-position="left" class="demo-table-expand">
                            <el-form-item label="园区">
                                <span>{{ props.row.campus }}</span>
                            </el-form-item>
                            <el-form-item label="楼栋">
                                <span>{{ props.row.building }}</span>
                            </el-form-item>
                            <el-form-item label="房间号">
                                <span>{{ props.row.roomNumber }}</span>
                            </el-form-item>
                        </el-form>
                    </template>
                </el-table-column>
                <el-table-column
                        label="申请描述"
                        prop="description"
                        width="150">
                </el-table-column>
                <el-table-column
                    prop="type"
                    label="申请类型"
                    width="150">
                </el-table-column>
                <el-table-column
                        prop="appName"
                        label="申请人"
                        width="150">
                </el-table-column>
                <el-table-column
                        prop="time"
                        label="申请时间"
                        width="180">
                </el-table-column>
                <el-table-column
                        prop="progress"
                        label="审批状态">
                </el-table-column>
                <el-table-column label="操作" width="120">
                    <template slot-scope="scope">
                        <el-button link type="text" size="small" @click="onPass(scope.row)"
                        >审批通过
                        </el-button>
                        <el-button link type="text" size="small" @click="onFail(scope.row)"
                        >审批不通过
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
<!--审批未通过理由-->
           <el-dialog
                    title="审批未通过"
                    :visible.sync="showFail"
                    width="30%"
                    :before-close="handleClose">
            <span>
                <el-form ref="failObj" label-width="200px" label-position="top">
                    <el-form-item label="审批不通过理由">
                        <el-input type="textarea" v-model="failObj.reason"></el-input>
                    </el-form-item>
                </el-form>
            </span>
                <span slot="footer" class="dialog-footer">
                <el-button @click="showFail = false">取 消</el-button>
                <el-button type="primary" @click="failConfirm">确 定</el-button>
            </span>
            </el-dialog>
        </el-card>
    </div>
</template>

<script>
import {counsellorGetApplicationList, counsellorCheck, stateChangeNo,
  houseparentGetApplicationList, stateChange, houseparentCheck} from '@api/application'
import {selectNameBySn} from '@api/user'
import {checkinInsert} from '@api/checkin'
import {getRoomId} from '@api/apartment'
import {mapGetters} from 'vuex'
import moment from 'moment'

export default {
  name: 'approval',
  computed: {
    ...mapGetters({
      userSn: 'user/getUserSn',
      userType: 'user/getUserType'
    })
  },
  data () {
    return {
      applicationData: [],
      showFail: false,
      reason: '',
      failObj: {}
      // arr: [{
      //   campus: 1,
      //   building: '1栋',
      //   roomId: 104,
      //   description: 'xxxxx'
      // }]
    }
  },
  methods: {
    getList () {
      if (this.userType === 2) {
        counsellorGetApplicationList({sn: this.userSn}).then(res => {
          this.applicationData = res.data
          console.log(res)
          this.applicationData.forEach(function (value, index, array) {
            array[index].time = moment(array[index].createTime).format('YYYY-MM-DD')
            selectNameBySn({sn: array[index].sn}).then(res => {
              array[index]['appName'] = res.data[0].name
            })
          })
        })
      } else {
        houseparentGetApplicationList({sn: this.userSn}).then(res => {
          console.log(res.data)
          this.applicationData = res.data
          this.applicationData.forEach(function (value, index, array) {
            array[index].time = moment(array[index].createTime).format('YYYY-MM-DD')
            selectNameBySn({sn: array[index].sn}).then(res => {
              array[index]['appName'] = res.data[0].name
            })
          })
        })
      }
    },
    async passConfirm (app) {
      let obj = {
        appId: app.id,
        approverSn: this.userSn,
        result: 1
      }
      console.log(app)
      // 辅导员审批通过
      if (this.userType === 2) {
        if (app.type === '入住申请') {
          counsellorCheck({id: app.id}).then(res => {
            this.$message({
              type: 'success',
              message: '审批通过'
            })
            this.getList()
          })
        }
      } else {
        //  宿舍管理员审核通过
        stateChange({id: app.id}).then(res => {
          houseparentCheck({id: app.id}).then(res => {
            if (app.type === '入住申请') {
              // 获取房间的id
              let roomObj = {
                campus: app.campus,
                building: app.building,
                roomNumber: app.roomNumber
              }
              getRoomId(roomObj).then(res => {
                checkinInsert({sn: app.sn, roomId: res.data[0].id}).then(res => {
                  this.$message({
                    type: 'success',
                    message: '入住通过'
                  })
                })
              })
            } else {
              this.$message({
                type: 'success',
                message: '审批通过'
              })
            }
            this.getList()
          })
        })
      }
    },
    onPass (app) {
      this.$confirm('确定通过次申请?', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        this.passConfirm(app)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消操作'
        })
      })
    },
    onFail (app) {
      this.showFail = true
      this.failObj = {
        appId: app.id,
        approverSn: this.userSn,
        result: 0,
        description: ''
      }
    },
    failConfirm () {
      // 辅导员审批未通过
      if (this.userType === 2) {
        stateChangeNo({id: this.failObj.appId}).then(res => {
          counsellorCheck({id: this.failObj.appId}).then(res => {
            this.$message({
              type: 'success',
              message: '审批未通过'
            })
            this.showFail = false
            this.getList()
          })
        })
      } else {
      //    宿舍管理员审批未通过
        stateChangeNo({id: this.failObj.appId}).then(res => {
          houseparentCheck({id: this.failObj.appId}).then(res => {
            this.$message({
              type: 'success',
              message: '审批未通过'
            })
            this.showFail = false
            this.getList()
          })
        })
      }
    }
  },
  created () {
    this.getList()
  }
}
</script>

<style>
    .demo-table-expand {
        font-size: 0;
    }
    .demo-table-expand label {
        width: 90px;
        color: #99a9bf;
    }
    .demo-table-expand .el-form-item {
        margin-right: 0;
        margin-bottom: 0;
        width: 50%;
    }
</style>
