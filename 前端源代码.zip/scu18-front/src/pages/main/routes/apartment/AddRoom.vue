<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/apartment/addRoom' }">添加住宿信息</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">

            <el-button type="primary" @click="showImport">导入数据</el-button>

            <!--导入-->
            <el-dialog
                    title="提示"
                    :visible.sync="showImportDialog"
                    width="30%"
                    :before-close="handleClose">
                <el-button type="text" size="small" @click="downloadTemp()">下载模板</el-button>
                <el-upload
                        class="upload-demo"
                        drag
                        action="./api/room/importRooms"
                        :on-success="importSuccess"
                        multiple>
                    <i class="el-icon-upload"></i>
                    <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                    <div class="el-upload__tip" slot="tip">请按模板上传.xls文件</div>
                </el-upload>
                <span slot="footer" class="dialog-footer">
    <el-button type="primary" @click="showImportDialog = false">确 定</el-button>
  </span>
            </el-dialog>
            <!--手动添加宿舍信息-->
            <el-form :label-position="right"
                     label-width="80px"
                     :model="roomInfo"
                     ref="roomInfo"
                     :rules="rules"
                     style="marg-left: 500px;">
                <el-form-item label="园区"
                              prop="campus">
                    <el-select v-model="roomInfo.campus">
                        <el-option label="西园" value="西园"></el-option>
                        <el-option label="东园" value="东园"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="楼栋"
                              prop="building">
                    <el-select v-model="roomInfo.building">
                        <el-option label="1栋" value="1栋"></el-option>
                        <el-option label="2栋" value="2栋"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="楼层" style="width:250px"
                              prop="floor">
                    <el-input v-model="roomInfo.floor"></el-input>
                </el-form-item>
                <el-form-item label="房间号" style="width:250px"
                              prop="roomNumber">
                    <el-input v-model="roomInfo.roomNumber"></el-input>
                </el-form-item>
                <el-form-item label="限住人数" style="width:250px" prop="size">
                    <el-input v-model="roomInfo.size"></el-input>
                </el-form-item>
                <el-form-item label="男女寝" style="width:250px" prop="gender">
                    <el-select v-model="roomInfo.gender">
                        <el-option label="男寝" value="男寝"></el-option>
                        <el-option label="女寝" value="女寝"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="租金（元/学年）" style="width:250px" props="rent">
                    <el-input v-model="roomInfo.rent"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onAdd('roomInfo')">添加</el-button>
                </el-form-item>
            </el-form>

        </el-card>
    </div>
</template>

<script>
import {exportTemp, addRoom} from '@api/apartment'
export default {
  name: 'AddRoom',
  data () {
    return {
      showImportDialog: false,
      roomInfo: {},
      rules: {
        campus: [
          { required: true, message: '请选择园区', trigger: 'blur' }
        ],
        building: [
          { required: true, message: '请选择楼栋', trigger: 'blur' }
        ],
        floor: [
          { required: true, message: '请输入楼层', trigger: 'blur' }
        ],
        roomNumber: [
          { required: true, message: '请输入房间号', trigger: 'blur' }
        ],
        size: [
          // { type: 'number', message: '请输入数字', trigger: 'blur' }
        ],
        rent: [
          // { type: 'number', message: '请输入租金（数字）', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    showImport () {
      this.showImportDialog = true
    },
    downloadTemp () {
      exportTemp().then(res => {
        // let blob = new Blob([res], {type: 'application/vnd.ms-excel'})
        // let url = window.URL.createObjectURL(blob)
        // let a = document.createElement('a')
        // a.herf = url
        // a.download = '导入模板.xls'
        // a.click()
        // window.URL.revokeObjectURL(url)

        const fileName = `房源导入模板.xls`
        const blob = new Blob([res], {type: 'application/vnd.ms-excel;charset=utf-8'})
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(blob, fileName)
        } else {
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = fileName
          link.click()
          URL.revokeObjectURL(link.href)
        }
      })
    },
    importSuccess (res, file) {
      console.log(res.data)
      if (res.data.error) {
        this.$message({
          type: 'error',
          message: res.data.error
        })
      } else {
        this.$message({
          type: 'success',
          message: res.data.success
        })
        this.showImportDialog = false
        this.queryAparts()
      }
    },

    //  手动添加数据
    onAdd (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          addRoom(this.roomInfo).then(res => {
            if (res.data) {
              this.$message({
                type: 'success',
                message: '添加成功!'
              })
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
</style>
