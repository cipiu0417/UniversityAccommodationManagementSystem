<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/apartment/apartment' }">房源</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
<!--            查询框-->
            <el-form :inline="true" :model="searchData" class="demo-form-inline"  label-width="80px">
                <el-row >
                    <el-col :span="6">
                        <el-form-item label="园区">
                            <el-select v-model="searchData.campus" placeholder="园区">
                                <el-option label="全部" value=""></el-option>
                                <el-option label="西园" value="西园"></el-option>
                                <el-option label="东园" value="东园"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                        <el-col :span="6">
                        <el-form-item label="楼栋">
                            <el-select v-model="searchData.building" placeholder="楼栋">
                                <el-option label="全部" value=""></el-option>
                                <el-option label="1栋" value="1栋"></el-option>
                                <el-option label="2栋" value="2栋"></el-option>
                                <el-option label="3栋" value="3栋"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="房间人数">
                            <el-select v-model="searchData.size" placeholder="房间人数">
                                <el-option label="全部" value=""></el-option>
                                <el-option label="双人间" value="2"></el-option>
                                <el-option label="四人间" value="4"></el-option>
                                <el-option label="六人间" value="6"></el-option>
                                <el-option label="八人间" value="8"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="男女寝">
                            <el-select v-model="searchData.gender" placeholder="男女寝">
                                <el-option label="全部" value=""></el-option>
                                <el-option label="男寝" value="男寝"></el-option>
                                <el-option label="女寝" value="女寝"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="13">
                                <el-form-item label="租金范围">
                                <el-select v-model="searchData.rent1" placeholder="不限" >
                                    <el-option label="不限" value="0">不限</el-option>
                                    <el-option label="500" value="500">500</el-option>
                                    <el-option label="1000" value="1000">1000</el-option>
                                    <el-option label="1500" value="1500">1500</el-option>
                                </el-select>
                                ~
                                <el-select v-model="searchData.rent2" placeholder="不限">
                                    <el-option label="不限" value="100000">不限</el-option>
                                    <el-option label="500" value="500">500</el-option>
                                    <el-option label="1000" value="1000">1000</el-option>
                                    <el-option label="2000" value="2000">2000</el-option>
                                </el-select>
                                元/学年
                                </el-form-item>
                        </el-col>
                        <el-col :span="2">
                            <el-form-item >
                                <el-button type="primary" @click="onQuery">查询</el-button>
                            </el-form-item>
                        </el-col>
                    <el-col :span="3">
                        <el-form-item>
                            <el-button type="primary" @click="onExportRooms">导出房源信息</el-button>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row v-if="userType === 3">
                    <el-col :offset="15"  :span="3" >
                        <el-form-item>
                            <el-button type="primary" @click="showImport">导入房源数据</el-button>
                        </el-form-item>
                    </el-col>
                    <el-col :span="3">
                        <el-form-item>
                            <el-button type="primary" @click="showAdd = true">添加房源信息</el-button>
                        </el-form-item>
                    </el-col>
                    <el-col :span="2">
                        <el-form-item>
                            <el-button type="primary" @click="onDeleteRooms">批量删除</el-button>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>

            <el-table
                    :data="apartmentData"
                    border
                    style="width: 100%"
                    @selection-change="handleSelectionChange">
                <el-table-column
                        type="selection"
                        width="55">
                </el-table-column>
                <el-table-column
                        prop="campus"
                        label="园区"
                        width="180">
                </el-table-column>
                <el-table-column
                        prop="building"
                        label="楼栋"
                        width="180">
                </el-table-column>
                <el-table-column
                        prop="floor"
                        label="楼层">
                </el-table-column>
                <el-table-column
                        prop="roomNumber"
                        label="房间号">
                </el-table-column>
                <el-table-column
                        prop="gender"
                        label="男女寝">
                </el-table-column>
                <el-table-column
                        prop="rent"
                        label="租金">
                </el-table-column>
                <el-table-column
                        prop="size"
                        label="限住人数">
                </el-table-column>
                <el-table-column label="操作" width="120">
                    <template slot-scope="scope">
                        <el-button link type="text" size="small" @click="handleEdit(scope.row)"
                        >编辑
                        </el-button>
                        <el-button link type="text" size="small" @click="handleDelete(scope.row)"
                        >删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="searchData.pageNo"
                        :page-size="searchData.pageSize"
                        :page-sizes="[5, 10, 20, 50]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                </el-pagination>
        </el-card>
        <!--        宿舍信息添加-->
        <el-dialog
                title="添加宿舍信息"
                :visible.sync="showAdd"
                width="30%"
                :before-close="handleClose">
            <span>
            <!--手动添加宿舍信息-->
            <el-form :label-position="left"
                     label-width="100px"
                     :model="newRoom"
                     ref="newRoom"
                     :rules="rules"
                     style="margin:0 30px 0 10px">
                <el-form-item label="园区"
                              prop="campus">
                    <el-select v-model="newRoom.campus">
                        <el-option label="西园" value="西园"></el-option>
                        <el-option label="东园" value="东园"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="楼栋"
                              prop="building">
                    <el-select v-model="newRoom.building">
                        <el-option label="1栋" value="1栋"></el-option>
                        <el-option label="2栋" value="2栋"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="楼层"
                              prop="floor">
                    <el-input v-model="newRoom.floor"></el-input>
                </el-form-item>
                <el-form-item label="房间号"
                              prop="roomNumber">
                    <el-input v-model="newRoom.roomNumber"></el-input>
                </el-form-item>
                <el-form-item label="限住人数" prop="size">
                    <el-input v-model="newRoom.size"></el-input>
                </el-form-item>
                <el-form-item label="男女寝" prop="gender">
                    <el-select v-model="newRoom.gender">
                        <el-option label="男寝" value="男寝"></el-option>
                        <el-option label="女寝" value="女寝"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="租金" props="rent">
                    <el-input v-model="newRoom.rent" placeholder="（元/学年）"></el-input>
                </el-form-item>
            </el-form>
            </span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="showAdd = false">取 消</el-button>
                <el-button type="primary" @click="onAdd('newRoom')">确 定</el-button>
            </span>
        </el-dialog>
        <!--导入-->
        <el-dialog
                title="导入房源数据"
                :visible.sync="showImportDialog"
                width="30%"
                :before-close="handleClose">
            <el-button type="text" size="small" @click="downloadTemp()">下载模板</el-button>
            <el-upload
                    class="upload-demo"
                    drag
                    action="./api/room/importRooms"
                    :on-success="importSuccess"
                    multiple>
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                <div class="el-upload__tip" slot="tip">请按模板上传.xls文件</div>
            </el-upload>
            <span slot="footer" class="dialog-footer">
    <el-button type="primary" @click="showImportDialog = false">取 消</el-button>
  </span>
        </el-dialog>

<!--        宿舍信息编辑-->
        <el-dialog
                title="提示"
                :visible.sync="showEdit"
                width="30%"
                :before-close="handleClose">
            <span>
                <el-form ref="currentRoom" label-width="80px">
                    <el-form-item label="房间号">
                        <el-input v-model="currentRoom.roomNumber"></el-input>
                    </el-form-item>
                    <el-form-item label="限住人数">
                        <el-input v-model="currentRoom.size"></el-input>
                    </el-form-item>
                    <el-form-item label="租金">
                        <el-input v-model="currentRoom.rent"></el-input>
                    </el-form-item>
                    <el-form-item label="男女寝">
                        <el-select v-model="currentRoom.gender">
                            <el-option label="男寝" value="男寝"></el-option>
                            <el-option label="女寝" value="女寝"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
            </span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="showEdit = false">取 消</el-button>
                <el-button type="primary" @click="editConfirm">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import {queryApartment, deleteRoom, deleteRooms, updateRoom, exportRooms, exportTemp, addRoom} from '@api/apartment'
import {mapGetters} from 'vuex'
export default {
  name: 'Apartment',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType'
    })
  },
  data () {
    return {
      total: 0,
      apartmentData: {},
      searchData: {
        campus: '',
        building: '',
        size: '',
        gender: '',
        rent1: '',
        rent2: '',
        pageNo: 1,
        pageSize: 5
      },
      manage: false,
      selectedRooms: [],
      showEdit: false,
      currentRoom: {},
      imageUrl: '',
      //  添加宿舍信息
      showImportDialog: false,
      newRoom: {},
      showAdd: false,
      rules: {
        campus: [
          { required: true, message: '请选择园区', trigger: 'blur' }
        ],
        building: [
          { required: true, message: '请选择楼栋', trigger: 'blur' }
        ],
        floor: [
          { required: true, message: '请输入楼层', trigger: 'blur' }
        ],
        roomNumber: [
          { required: true, message: '请输入房间号', trigger: 'blur' }
        ],
        size: [
          // { type: 'number', message: '请输入数字', trigger: 'blur' }
        ],
        rent: [
          // { type: 'number', message: '请输入租金（数字）', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.queryAparts()
    },
    handleCurrentChange (value) {
      console.log(value)
      this.searchData.pageNo = value
      this.queryAparts()
    },
    queryAparts () {
      queryApartment(this.searchData).then(res => {
        this.apartmentData = res.data.records
        this.total = res.data.total
      })
    },
    onQuery () {
      this.queryAparts()
    },

    //  添加宿舍信息
    //  手动添加数据
    onAdd (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          addRoom(this.newRoom).then(res => {
            if (res.status) {
              this.$message({
                type: 'success',
                message: '添加成功!'
              })
              this.newRoom = []
              this.showAdd = false
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    //  导入数据
    showImport () {
      this.showImportDialog = true
    },
    downloadTemp () {
      exportTemp().then(res => {
        const fileName = `房源导入模板.xls`
        const blob = new Blob([res], {type: 'application/vnd.ms-excel;charset=utf-8'})
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(blob, fileName)
        } else {
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = fileName
          link.click()
          URL.revokeObjectURL(link.href)
        }
      })
    },
    importSuccess (res, file) {
      console.log(res.data)
      if (res.data.error) {
        this.$message({
          type: 'error',
          message: res.data.error
        })
      } else {
        this.$message({
          type: 'success',
          message: res.data.success
        })
        this.showImportDialog = false
        this.queryAparts()
      }
    },
    handleDelete (room) {
      this.$confirm('此操作将永久删该宿舍信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteRoom({id: room.id}).then(res => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.queryAparts()
          }
        })
      })
    },
    //  导出房源信息
    onExportRooms () {
      exportRooms(this.searchData).then(res => {
        // const fileName = `${+new Date()}.xlsx`
        const fileName = `房源信息.xlsx`
        const blob = new Blob([res], {type: 'application/vnd.ms-excel;charset=utf-8'})
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(blob, fileName)
        } else {
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = fileName
          link.click()
          URL.revokeObjectURL(link.href)
        }
      })
    },
    // 批量删除
    onDeleteRooms () {
      let arr = this.selectedRooms.map(x => x.id)
      if (arr.length <= 0) {
        this.$message({
          message: '请至少选择一条要删除的数据',
          type: 'warning'
        })
        return
      }
      this.$confirm('此操作将永久删除选定宿舍信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteRooms({ids: arr}).then(res => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.queryAparts()
          }
        })
      })
    },
    handleSelectionChange (value) {
      this.selectedRooms = value
    },

    //    宿舍编辑
    handleEdit (room) {
      this.showEdit = true
      this.currentRoom = room
      this.imageUrl = room.url
      console.log(room)
    },
    editConfirm () {
      updateRoom(this.currentRoom).then(res => {
        if (res.data) {
          this.$message({
            type: 'success',
            message: '编辑成功!'
          })
          this.queryAparts()
        }
      })
      this.showEdit = false
    }
  },
  created () {
    this.queryAparts()
  }
}
</script>

<style scoped>
</style>
