<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/admin/stuManage' }">学生管理</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
<!--             下拉框-->
<!--            <el-select v-model="value" placeholder="选择要查看的用户类型">-->
<!--                <el-option-->
<!--                        v-for="item in roleTypes"-->
<!--                        :key="item.value"-->
<!--                        :label="item.label"-->
<!--                        :value="item.value">-->
<!--                </el-option>-->
<!--            </el-select>-->

            <el-form inline label-width="60px"
                     :model="searchData"
                     ref="searchData"
                     style="height: 140px;">
                <el-row>
                    <el-form-item label="身份" prop="roleType">
                        <el-select v-model="searchData.roleType" placeholder="学生">
                            <el-option
                                    v-for="item in roleTypes"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
<!--                            <el-option label="学生" value="1"></el-option>-->
<!--                            <el-option label="辅导员" value="2"></el-option>-->
<!--                            <el-option label="宿舍管理员" value="3"></el-option>-->
<!--                            <el-option label="维修管理员" value="4"></el-option>-->
                        </el-select>
                    </el-form-item>
                    <el-form-item label="账号" prop="sn">
                        <el-input v-model="searchData.sn"></el-input>
                    </el-form-item>
                    <el-form-item label="姓名" prop="name">
                        <el-input v-model="searchData.name"></el-input>
                    </el-form-item>
                    <el-form-item label="性别" prop="gender">
                        <el-select v-model="searchData.gender">
                            <el-option label="男" value="false"></el-option>
                            <el-option label="女" value="true"></el-option>
                        </el-select>
                    </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="getUsers" >
                                查询
                            </el-button>
                        </el-form-item>
                </el-row>
                <el-row v-if="searchData.roleType == 1">
                    <el-form-item  label="年级" prop="grade">
                        <el-select v-model="searchData.grade">
                            <el-option label="2019" value="2019"></el-option>
                            <el-option label="2020" value="2020"></el-option>
                            <el-option label="2021" value="2021"></el-option>
                            <el-option label="2022" value="2022"></el-option>
                            <el-option label="2023" value="2023"></el-option>
                            <el-option label="2024" value="2024"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="学院" prop="college">
                        <el-input v-model="searchData.college"></el-input>
                    </el-form-item>
                </el-row>
            </el-form>
            <!--操作：添加/导入/批量删除-->
            <el-row style="margin-bottom: 30px;">
                <el-button type="primary" @click="showAdd = true">添加用户信息</el-button>
                <el-button type="primary" @click="showImport">导入用户数据</el-button>
                <el-button type="danger" @click="onDeleteUsers">批量删除</el-button>
            </el-row>
            <!--用户信息表-->
            <el-table ref="multipleTable"
                      :data=tableData
                      tooltip-effect="dark"
                      @selection-change="handleSelectionChange"
                      style="width: 100%">
                <el-table-column type="selection" width="55">
                </el-table-column>
                <el-table-column label="身份" prop="roleType">
                </el-table-column>
                <el-table-column label="账号" prop="sn">
                </el-table-column>
                <el-table-column label="姓名" prop="name">
                </el-table-column>
                <el-table-column label="性别" prop="gender">
                </el-table-column>
                <el-table-column v-if="roleType == 1" label="年级" prop="grade">
                </el-table-column>
                <el-table-column v-if="roleType == 1 || roleType == 2" label="学院" prop="college">
                </el-table-column>
                <el-table-column v-if="roleType == 1" label="辅导员工号" prop="counsellorSn">
                </el-table-column>
                <el-table-column label="电话" prop="phone">
                </el-table-column>
                <el-table-column align="right" label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                        <el-button type="text" size="small" @click="handleDelete(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页-->
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                :current-page="searchData.pageNo" :page-size="searchData.pageSize" :page-sizes="[5, 10, 20, 50]"
                layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
        </el-card>
        <!--用户信息添加-->
        <el-dialog title="添加用户信息" :visible.sync="showAdd" width="50%" :before-close="handleClose">
            <span>
                <!--手动添加用户信息-->
                <el-form :label-position="left" label-width="100px" :model="newUser" ref="newUser" :rules="rules"
                    style="margin:0 30px 0 10px">
                    <el-form-item label="身份" prop="roleType">
                        <el-select v-model="newUser.roleType" @change="() => { typeChange(newUser.roleType) }">
                            <el-option label="学生" value="1"></el-option>
                            <el-option label="宿管" value="2"></el-option>
                            <el-option label="辅导员" value="3"></el-option>
                            <el-option label="维修工" value="4"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="账号" prop="sn">
                        <el-input v-model="newUser.sn"></el-input>
                    </el-form-item>
                    <el-form-item label="密码">
                        <el-input readonly placeholder="初始化为默认值"></el-input>
                    </el-form-item>
                    <el-form-item label="姓名" prop="name">
                        <el-input v-model="newUser.name"></el-input>
                    </el-form-item>
                    <el-form-item v-if="showGrade" label="年级" prop="grade">
                        <el-select v-model="newUser.grade">
                            <el-option label="2019" value="2019"></el-option>
                            <el-option label="2020" value="2020"></el-option>
                            <el-option label="2021" value="2021"></el-option>
                            <el-option label="2022" value="2022"></el-option>
                            <el-option label="2023" value="2023"></el-option>
                            <el-option label="2024" value="2024"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="性别" prop="gender">
                        <el-select v-model="newUser.gender">
                            <el-option label="男" value="false"></el-option>
                            <el-option label="女" value="true"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item v-if="showCollege" label="学院" prop="college">
                        <el-input v-model="newUser.college"></el-input>
                    </el-form-item>
                    <el-form-item v-if="showCoun" label="辅导员工号" prop="counsellorSn">
                        <el-input v-model="newUser.counsellorSn"></el-input>
                    </el-form-item>
                    <el-form-item label="电话" prop="phone">
                        <el-input v-model="newUser.phone"></el-input>
                    </el-form-item>
                </el-form>
            </span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="showAdd = false">取 消</el-button>
                <el-button type="primary" @click="onAdd('newUser')">确 定</el-button>
            </span>
        </el-dialog>
        <!--导入-->
        <el-dialog title="导入用户数据" :visible.sync="showImportDialog" width="30%" :before-close="handleClose">
            <el-button type="text" size="small" @click="downloadStuTemp()">下载学生数据模板</el-button>
            <br>
            <el-button type="text" size="small" @click="downloadCounTemp()">下载辅导员数据模板</el-button>
            <br>
            <el-button type="text" size="small" @click="downloadHouseTemp()">下载宿管数据模板</el-button>
            <el-upload class="upload-demo"
                       drag
                       :on-success="importSuccess"
                        action="./api/user/importUsers">
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                <div class="el-upload__tip" slot="tip">请按模板上传.xls文件</div>
            </el-upload>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="showImportDialog = false">取 消</el-button>
            </span>
        </el-dialog>
        <!--用户信息编辑-->
        <el-dialog title="提示" :visible.sync="showEdit" width="40%" :before-close="handleClose">
            <span>
                <el-form ref="currentUser" label-width="100px">
                    <el-form-item label="账号">
                        <el-input v-model="currentUser.sn" :disabled="true"></el-input>
                    </el-form-item>
                    <el-form-item label="姓名">
                        <el-input v-model="currentUser.name" :disabled="true"></el-input>
                    </el-form-item>
                    <el-form-item label="年级">
                        <el-input v-model="currentUser.grade"></el-input>
                    </el-form-item>
                    <el-form-item label="性别">
                        <el-input v-model="currentUser.gender" :disabled="true"></el-input>
                    </el-form-item>
                    <el-form-item label="学院">
                        <el-input v-model="currentUser.college"></el-input>
                    </el-form-item>
                    <el-form-item label="辅导员工号">
                        <el-input v-model="currentUser.counsellorSn"></el-input>
                    </el-form-item>
                    <el-form-item label="电话">
                        <el-input v-model="currentUser.phone"></el-input>
                    </el-form-item>
                </el-form>
            </span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="showEdit = false">取 消</el-button>
                <el-button type="primary" @click="resetPsd">重置密码</el-button>
                <el-button type="primary" @click="editConfirm">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import { userRemoveByIds, userRemoveById, exportCounsellorTemp, exportHouseparentTemp, exportStudentTemp, userInsert, userPageList, userUpdate } from '@api/user'
import { mapGetters } from 'vuex'
export default {
  name: 'UserManage',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType'
    })
  },
  data () {
    return {
      total: 0,
      roleTypes: [{
        value: '1',
        label: '学生'
      }, {
        value: '2',
        label: '辅导员'
      }, {
        value: '3',
        label: '宿舍管理员'
      }, {
        value: '4',
        label: '维修管理员'
      }],
      userData: {},
      searchData: {
        roleType: '',
        sn: '',
        name: '',
        grade: '',
        gender: '',
        pageNo: 1,
        pageSize: 5
      },
      manage: false,
      selectedUsers: [],
      showEdit: false,
      currentUser: {},
      // 添加用户信息
      showImportDialog: false,
      newUser: {
        password: '123456'
      },
      showAdd: false,
      showGrade: false, // 年级
      showCollege: false, // 学院
      showCoun: false, // 辅导员工号
      rules: {
        roleType: [
          { required: true, message: '请选择用户身份', trigger: 'change' }
        ],
        sn: [
          { required: true, message: '请输入用户账号', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请录入用户姓名', trigger: 'blur' }
        ],
        grade: [
          { required: true, message: '请选择用户年级', trigger: 'blur' }
        ],
        gender: [
          { required: true, message: '请选择用户性别', trigger: 'change' }
        ],
        college: [
          { required: true, message: '请输入用户所在学院', trigger: 'blur' }
        ],
        counsellorSn: [
          { required: true, message: '请输入辅导员工号', trigger: 'blur' }
        ]
      },
      tableData: [],
      multipleSelection: []
    }
  },
  methods: {
    //  获取用户列表
    getUsers () {
      userPageList(this.searchData).then(res => {
        this.tableData = res.data.records
        this.tableData.forEach(function (value, index, array) {
          array[index].gender = array[index].gender ? '女' : '男'
          if (array[index].roleType === 1) array[index].roleType = '学生'
          else if (array[index].roleType === 2) array[index].roleType = '辅导员'
          else if (array[index].roleType === 3) array[index].roleType = '宿舍管理员'
        })
        console.log(this.tableData)
      })
    },
    // 根据角色填入字段
    typeChange (selectValue) {
      console.info(selectValue)
      if (selectValue == '维修工' || selectValue == '辅导员' || selectValue == '宿管') {
        this.showGrade = false
        this.showCoun = false
        if (selectValue == '维修工') {
          this.showCollege = false
        } else {
          this.showCollege = true
        }
      } else {
        this.showCoun = true
        this.showGrade = true
        this.showCollege = true
      }
    },
    // 分页
    handleSizeChange (value) {
      this.searchData.pageSize = value
      this.queryAparts()
    },
    handleCurrentChange (value) {
      this.searchData.pageNo = value
      this.queryAparts()
    },
    // 添加用户信息
    // 手动添加用户数据
    onAdd (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          userInsert(this.newUser).then(res => {
            if (res.status) {
              this.$message({
                type: 'success',
                message: '添加成功!'
              })
              this.newUser = {
                password: '123456'
              }
              this.showAdd = false
            }
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 导入用户数据
    showImport () {
      this.showImportDialog = true
    },
    downloadStuTemp () {
      exportStudentTemp().then(res => {
        const fileName = `学生数据导入模板.xls`
        const blob = new Blob([res], { type: 'application/vnd.ms-excel;charset=utf-8' })
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(blob, fileName)
        } else {
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = fileName
          link.click()
          URL.revokeObjectURL(link.href)
        }
      })
    },
    downloadCounTemp () {
      exportCounsellorTemp().then(res => {
        const fileName = `辅导员数据导入模板.xls`
        const blob = new Blob([res], { type: 'application/vnd.ms-excel;charset=utf-8' })
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(blob, fileName)
        } else {
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = fileName
          link.click()
          URL.revokeObjectURL(link.href)
        }
      })
    },
    downloadHouseTemp () {
      exportHouseparentTemp().then(res => {
        const fileName = `宿舍管理员数据导入模板.xls`
        const blob = new Blob([res], { type: 'application/vnd.ms-excel;charset=utf-8' })
        if (navigator.msSaveBlob) {
          navigator.msSaveBlob(blob, fileName)
        } else {
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = fileName
          link.click()
          URL.revokeObjectURL(link.href)
        }
      })
    },
    importSuccess (res, file) {
      console.log(res.data)
      if (res.data.error) {
        this.$message({
          type: 'error',
          message: res.data.error
        })
      } else {
        this.$message({
          type: 'success',
          message: res.data.success
        })
        this.showImportDialog = false
        this.getUsers()
      }
    },

    // 编辑用户信息
    handleEdit (user) {
      this.showEdit = true
      this.currentUser = user
      console.log(user)
    },
    editConfirm () {
      let obj = {
        grade: this.currentUser.grade,
        counsellorSn: this.currentUser.counsellorSn,
        college: this.currentUser.college,
        phone: this.currentUser.phone
      }
      userUpdate(obj).then(res => {
        if (res.data) {
          this.$message({
            type: 'success',
            message: '编辑成功!'
          })
          this.getUsers()
        }
      })
      this.showEdit = false
    },
    // 删除用户信息
    handleDelete (user) {
      this.$confirm('此操作将删该用户信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        userRemoveById({ id: user.id }).then(res => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.getUsers()
          }
        })
      })
    },
    // 批量删除
    onDeleteUsers () {
      let arr = this.selectedUsers.map(x => x.id)
      if (arr.length <= 0) {
        this.$message({
          message: '请至少选择一条要删除的数据',
          type: 'warning'
        })
        return
      }
      this.$confirm('此操作将永久删除选定用户信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        console.log(arr)
        userRemoveByIds({ ids: arr }).then(res => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.getUsers()
          }
        })
      })
    },
    handleSelectionChange (val) {
      this.selectedUsers = val
    }
  },
  created () {
    this.searchData.roleType = this.roleTypes[0].value
    this.getUsers()
  }
}

</script>

<style scoped></style>
