<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/maintain/assignment' }">维修人员分配</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <!--审核报修+人员分配-->
        <el-card class="container">
            <el-table style="width: 100%"
                    :data="maintainData">
                <el-table-column prop="name" label="报修学生" width="100">
                </el-table-column>
                <el-table-column prop="maintainType" label="报修信息" width="200">
                </el-table-column>
                <el-table-column prop="worker" label="维修工" width="100">
                </el-table-column>
                <el-table-column prop="progress" label="分配状态" width="100"
                    :filters="[{ text: '待分配', value: '待分配' }, { text: '等待维修', value: '等待维修' }]" :filter-method="filterTag"
                    filter-placement="bottom-end">
                    <template slot-scope="scope">
                        <el-tag :type="scope.row.progress === '待分配' ? 'primary' : 'success'"
                                disable-transitions>{{ scope.row.progress
                        }}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column align="right">
                <template slot="header" slot-scope="scope">
                    <el-input v-model="search" size="mini" placeholder="输入审核人关键字搜索" />
                </template>
                <template slot-scope="scope">
                    <el-button size="mini" @click="onAssign(scope.row)" type="success">分配</el-button>

                </template>
                </el-table-column>
            </el-table>
        </el-card>
        <!-- 维修人员分配编辑 -->
        <el-dialog title="维修分配" :visible.sync="showEdit" width="30%" :before-close="handleClose">
            <span>
                <el-form ref="currentAssignment" label-width="80px">

                    <el-form-item label="维修工">
                        <el-select
                                v-model="currentAssignment.maintainer_sn">
                            <el-option :label="item.name"
                                       :value="item.sn"
                                       v-for="(item) in this.maintainerList">

                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
            </span>
            <span slot="footer" class="dialog-footer">
                <el-button @click="showEdit = false">取 消</el-button>
                <el-button type="primary" @click="assignConfirm">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import {getMaintainerList, assignMaintainer} from '@api/maintain'
import {getMaintainList} from '@api/application'
import {selectNameBySn} from '@api/user'
import {mapGetters} from 'vuex'
export default {
  name: 'Assignment',
  data () {
    return {
      showEdit: false,
      currentAssignment: {},
      search: '',
      maintainerList: [],
      maintainData: []
    }
  },
  computed: {
    ...mapGetters({
      userType: 'user/getUserType',
      userName: 'user/getUserName',
      userSn: 'user/getUserSn'
    })
  },
  methods: {
    getMaintainData () {
      let obj = {
        roleType: this.userType,
        sn: this.userSn
        // pageSize: 10
        // pageNo: 1,
      }
      getMaintainList(obj).then(res => {
        this.maintainData = res.data.records
        this.maintainData.forEach(function (value, index, array) {
          console.log(array[index].maintainerSn)
          selectNameBySn({sn: array[index].maintainerSn}).then(res => {
            array[index]['worker'] = res.data[0].name
          })
          selectNameBySn({sn: array[index].sn}).then(res => {
            array[index]['name'] = res.data[0].name
          })
        })
        console.log(this.maintainData)
      })
    },
    // formatter (row, column) {
    //   return row.message
    // },
    filterTag (value, row) {
      return row.progress === value
    },
    // 维修人员分配
    onAssign (row) {
      this.showEdit = true
      this.currentAssignment = row
      this.getMaintainerData()
    },
    //  获取维修人员列表
    getMaintainerData () {
      getMaintainerList().then(res => {
        this.maintainerList = res.data
      })
    },
    assignConfirm () {
      let obj = {
        id: this.currentAssignment.id,
        maintainerSn: this.currentAssignment.maintainer_sn
      }
      console.log(obj)
      assignMaintainer(obj).then(res => {
        if (res.data) {
          this.$message({
            type: 'success',
            message: '分配成功!'
          })
          this.getMaintainData()
        }
      })
      this.showEdit = false
    }
  },
  mounted () {
    this.getMaintainData()
  }
}
</script>

<style scoped></style>
