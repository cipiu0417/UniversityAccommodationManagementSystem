<template>
    <div>
        <el-card class="crumbs-card">
            <div class="crumbs">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item :to="{ path: '/main/maintain/maintainList' }">维修列表</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </el-card>
        <el-card class="container">
            <!-- 学生姓名 联系电话 维修对象 预约时间 维修地址 任务状态 -->
            <el-table style="width: 100%"
                :data=listData>
                <el-table-column type="expand">
                    <template slot-scope="props">
                        <el-form label-position="left" inline class="demo-table-expand">
                            <el-form-item label="维修对象">
                                <span>{{ props.row.maintainType }}</span>
                            </el-form-item>
                            <el-form-item label="学生姓名">
                                <span>{{ props.row.name }}</span>
                            </el-form-item>
                            <el-form-item label="报修描述">
                                <span>{{ props.row.description }}</span>
                            </el-form-item>
                            <el-form-item label="联系电话">
                                <span>{{ props.row.phone }}</span>
                            </el-form-item>
                            <el-form-item label="预约时间">
                                <span>{{ props.row.maintainTime }}</span>
                            </el-form-item>
                            <el-form-item label="维修地址">
                                <span>{{ props.row.address }}</span>
                            </el-form-item>
                        </el-form>
                    </template>
                </el-table-column>
                <el-table-column label="预约时间" prop="maintainTime">
                </el-table-column>
                <el-table-column label="维修对象" prop="maintainType">
                </el-table-column>
                <el-table-column label="维修地址" prop="address">
                </el-table-column>
                <el-table-column label="任务状态" prop="progress"
                                 :filters="[{ text: '维修完成', value: '维修完成' }, { text: '等待维修', value: '等待维修' }]" :filter-method="filterTag"
                                 filter-placement="bottom-end">
                    <template slot-scope="scope">
                        <el-tag :type="scope.row.progress === '维修完成' ? 'success' : 'danger'" disable-transitions>{{
                            scope.row.progress }}</el-tag>
                    </template>
                </el-table-column>
                <!--关键字搜索+操作-->
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button v-if="scope.row.progress !=='维修完成'" type="primary" size="mini" @click="handleComplete(scope.row)">维修完成</el-button>
                        <span v-else style="color: darkseagreen">已完成</span>
                    </template>
                </el-table-column>
            </el-table>
        </el-card>
    </div>
</template>

<script>
import {showList, maintainComplete} from '@api/maintain'
import {selectNameBySn} from '@api/user'
import {mapGetters} from 'vuex'
import moment from 'moment'
export default {
  name: 'MaintainList',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType',
      userName: 'user/getUserName',
      userSn: 'user/getUserSn'
    })
  },
  data () {
    return {
      listData: [],
      search: ''
    }
  },
  methods: {
    //  获取维修任务列表
    getList () {
      showList({sn: this.userSn, state: '等待维修'}).then(res => {
        console.log(res.data)
        this.listData = res.data.records
        this.listData.forEach(function (value, index, array) {
          selectNameBySn({sn: array[index].sn}).then(res => {
            array[index]['name'] = res.data[0].name
            array[index].maintainTime = moment(array[index].maintainTime).format('YYYY-MM-DD')
          })
        })
      })
    },
    // 维修人员完成任务
    handleComplete (row) {
      console.log(row)
      this.$confirm('确定完成此维修任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        maintainComplete({id: row.id}).then(res => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '维修任务结束'
            })
            this.getList()
          }
        })
      })
    },
    filterTag (value, row) {
      return row.progress === value
    }
    // editConfirm () {
    // // 调用接口
    //   updateRoom(this.currentMaintainList).then(res => {
    //     if (res.data) {
    //       this.$message({
    //         type: 'success',
    //         message: '编辑成功!'
    //       })
    //     // this.queryAparts()
    //     }
    //   })
    //   this.showEdit = false
    // }
  },
  created () {
    this.getList()
  }
}
</script>

<style scoped>
.demo-table-expand {
    font-size: 0;
}

.demo-table-expand label {
    width: 90px;
    color: #99a9bf;
}

.demo-table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;
}
</style>
