<template>
  <div>
    <el-card class="crumbs-card">
      <div class="crumbs">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/main/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/main/maintain/registration' }">维修信息登记</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
    </el-card>
    <el-card class="container">
      <!--维修申请表-->
      <div>
        <div class="wj_box">
          <div class="index">
            <el-progress style="margin-left: 1.4rem;" :percentage="percentage" status="success"></el-progress>
          </div>
          <div class="wj_img">
            <div class="wj_count">
              <h2 style="text-align: center">学生宿舍维修申请表</h2>
              <h4 style="text-align: center">请仔细填写以下学生维修申请表单上报维修信息，提交申请后将交由宿管进行审核，请耐心等待结果。</h4>
              <div>
                <el-form :model="maintainForm" :rules="rules" ref="maintainForm" label-width="100px"
                  class="demo-maintainForm">
                  <el-form-item label="你的姓名">
                    <el-input v-model="this.userName" readonly></el-input>
                  </el-form-item>
                  <el-form-item label="你的电话" prop="phone">
                    <el-input v-model="maintainForm.phone"
                      @change="maintainForm.phone !== '' ? increase() : decrease()"></el-input>
                  </el-form-item>
                  <el-form-item label="维修对象" prop="maintainType">
                    <el-radio-group v-model="maintainForm.maintainType" class="xl"
                      @change="maintainForm.maintainType !== '' ? increase() : decrease()">
                      <el-radio label="桌椅"></el-radio>
                      <el-radio label="门窗"></el-radio>
                      <el-radio label="电灯"></el-radio>
                      <el-radio label="床柜"></el-radio>
                      <el-radio label="空调"></el-radio>
                      <el-radio label="卫生间"></el-radio>
                      <el-radio label="其他"><el-input v-model="input" placeholder="其他报修对象"></el-input></el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item label="维修时间" required>
                    <el-col :span="11">
                      <el-form-item prop="maintainTime">
                        <el-date-picker @change="maintainForm.maintainTime !== '' ? increase() : decrease()" type="datetime"
                          placeholder="选择日期时间" v-model="maintainForm.maintainTime" style="width: 100%"
                          default-time="10:00:00"></el-date-picker>
                      </el-form-item>
                    </el-col>
                  </el-form-item>
                  <el-form-item label="维修描述" prop="description">
                    <el-input type="textarea" v-model="maintainForm.description"
                              @change="maintainForm.description !== '' ? increase() : decrease()"></el-input>
                  </el-form-item>
                  <el-form-item label="维修地址" prop="address">
                    <el-input type="textarea" v-model="maintainForm.address"
                      @change="maintainForm.address !== '' ? increase() : decrease()"></el-input>
                  </el-form-item>
                  <el-form-item>
                    <el-button type="primary" @click="submitForm('maintainForm')">提交申请</el-button>
                    <el-button @click="resetForm('maintainForm')">重置</el-button>
                  </el-form-item>
                </el-form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 查看申请历史-->
<!--      <div>-->
<!--        <el-button @click="showHistory" type="primary" style="margin-left: 100px;">-->
<!--          查看申请历史-->
<!--        </el-button>-->

<!--        <el-drawer title="申请历史记录" :visible.sync="drawer" :with-header="false">-->
<!--          <div class="block">-->
<!--            <el-timeline>-->
<!--              <el-timeline-item :timestamp="item.createTime" placement="top" v-for="(item, index) in this.myHistory">-->
<!--                <el-card>-->
<!--                  <h4>{{ item.type }}</h4>-->
<!--                  <p>{{ item.description }}</p>-->
<!--                  <span>{{ item.progress }}</span>-->
<!--                </el-card>-->
<!--              </el-timeline-item>-->
<!--            </el-timeline>-->
<!--          </div>-->
<!--        </el-drawer>-->
<!--      </div>-->
    </el-card>
  </div>
</template>

<script>
import { saveMaintainRecord } from '@api/application'
import { mapGetters } from 'vuex'
export default {
  name: 'Registration',
  computed: {
    ...mapGetters({
      userType: 'user/getUserType',
      userName: 'user/getUserName',
      userSn: 'user/getUserSn'
    })
  },
  data () {
    return {
      count: 0,
      percentage: 0,
      maintainForm: {},
      input: '',
      drawer: false,
      rules: {
        phone: [
          { required: true, message: '请输入电话', trigger: 'blur' },
          { min: 11, max: 11, message: '长度在 11 个字符', trigger: 'blur' }
        ],
        maintainTime: [
          {
            type: 'date',
            required: true,
            message: '请选择日期',
            trigger: 'change'
          }
        ],
        maintainType: [
          {
            required: true,
            message: '请选择维修对象',
            trigger: 'change'
          }
        ],
        description: [
          { required: true, message: '请输入维修描述', trigger: 'blur' }
        ],
        address: [
          { required: true, message: '请输入维修地址', trigger: 'blur' }
        ]
      },
      myHistory: []
    }
  },
  methods: {
    //  查看历史记录
    showHistory () {
      this.drawer = true
      getApplications({sn: this.userSn, roleType: this.userType}).then(res => {
        this.myHistory = res.data.records
      })
    },
    increase () {
      this.percentage += 20
      if (this.percentage > 87.5) {
        this.percentage = 100
      }
    },
    decrease () {
      this.percentage -= 20
      if (this.percentage < 0) {
        this.percentage = 0
      }
    },
    submitForm (formName) { // 提交事件
      this.$refs[formName].validate(valid => {
        if (valid) {
          let obj = this.maintainForm
          Object.assign(obj, { sn: this.userSn })
          saveMaintainRecord(obj).then(res => {
            this.$message({
              type: 'success',
              message: '提交成功'
            })
            this.resetForm('maintainForm')
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) { // 重置
      this.$refs[formName].resetFields()
    }
  }

}
</script>

<style scoped></style>
