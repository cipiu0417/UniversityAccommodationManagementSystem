<template>
    <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import * as echarts from 'echarts'
import {weekNumber} from '@api/sanitation'
require('echarts/theme/macarons') // echarts theme

export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    }
  },
  data () {
    return {
      chart: null,
      arr: []
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy () {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    async getWeekList () {
      await weekNumber({week: 1}).then(res => {
        this.arr = res.data
      })
    },
    async initChart () {
      await this.getWeekList()
      this.chart = echarts.init(this.$el, 'macarons')

      let option = {
        title: {
          text: '分数占比',
          left: 'left'
        },
        tooltip: {
          trigger: 'item'
        },
        series: [
          {
            name: '寝室数量',
            type: 'pie',
            radius: '50%',
            data: [
              { value: 104, name: '卫生优秀寝室' },
              { value: 73, name: '卫生良好寝室' },
              { value: 58, name: '卫生中等寝室' },
              { value: 48, name: '卫生较差寝室' },
              { value: 30, name: '卫生不及格寝室' }
            ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
      for (let i = 0; i < 5; i++) {
        option.series[0].data[i].value = this.arr[3][i]
      }
      this.chart.setOption(option)
    }
  }
}
</script>
