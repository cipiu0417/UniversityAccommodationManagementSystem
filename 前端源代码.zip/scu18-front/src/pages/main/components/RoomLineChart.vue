<template>
        <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import * as echarts from 'echarts'
import {selectScoresByWeek} from '@api/sanitation'
require('echarts/theme/macarons') // echarts theme

export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    }
  },
  data () {
    return {
      chart: null,
      arr: [],
      option: {}
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy () {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    //  传入第几周和寝室id
    async getScoreList (w, rid) {
      this.arr = []
      for (let i = w; i > 0 && (w - i) < 7; i--) {
        await selectScoresByWeek({week: i, roomId: rid}).then(res => {
          this.arr.push(res.data)
        })
      }
    },
    async updateChart (w, rid) {
      await this.getScoreList(w, rid)
      for (let i = 0; i < 4; i++) {
        for (let j = this.arr.length - 1; j >= 0; j--) {
          this.option.series[i].data.push(this.arr[j][i])
        }
      }
      this.chart.setOption(this.option)
    },
    async initChart () {
      this.chart = echarts.init(this.$el, 'macarons')
      this.option = {
        title: {
          text: '寝室得分变化情况'
        },
        legend: {
          orient: 'vertical',
          x: 'right',
          y: 'top'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        xAxis: {
          type: 'category',
          name: '周数',
          data: []
        },
        yAxis: {
          type: 'value',
          name: '卫生得分'
        },
        series: [
          {
            data: [],
            type: 'line',
            name: '房间得分',
            smooth: true
          }, {
            data: [],
            type: 'line',
            name: '阳台得分',
            smooth: true
          }, {
            data: [],
            type: 'line',
            name: '卫生间得分',
            smooth: true
          }, {
            data: [],
            type: 'line',
            name: '总体得分',
            smooth: true
          }
        ]
      }
      this.chart.setOption(this.option)
    }
  }
}
</script>
