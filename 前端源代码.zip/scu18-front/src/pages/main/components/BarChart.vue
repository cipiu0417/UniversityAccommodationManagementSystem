<template>
    <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import * as echarts from 'echarts'
import {weekNumber} from '@api/sanitation'
require('echarts/theme/macarons') // echarts theme

export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    }
  },
  data () {
    return {
      chart: null,
      arr: []
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy () {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    async getWeekList () {
      await weekNumber({week: 1}).then(res => {
        this.arr = res.data
      })
    },
    async initChart () {
      await this.getWeekList()
      this.chart = echarts.init(this.$el, 'macarons')
      let option = {
        title: {
          text: '卫生情况寝室数'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        legend: {
          orient: 'vertical',
          x: 'right',
          y: 'top'
        },

        xAxis: [
          {
            type: 'category',
            data: ['房间卫生', '阳台卫生', '卫生间卫生', '整体卫生'],
            axisTick: {
              alignWithLabel: true
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '寝室数量'
          }
        ],
        series: [
          {
            name: '优秀寝室数',
            type: 'bar',
            barWidth: '15%',
            data: []
          }, {
            name: '良好寝室数',
            type: 'bar',
            barWidth: '15%',
            data: []
          }, {
            name: '中等寝室数',
            type: 'bar',
            barWidth: '15%',
            data: []
          }, {
            name: '较差寝室数',
            type: 'bar',
            barWidth: '15%',
            data: []
          }, {
            name: '不及格寝室数',
            type: 'bar',
            barWidth: '15%',
            data: []
          }
        ]
      }
      for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 4; j++) {
          option.series[i].data.push(this.arr[j][i])
        }
      }
      this.chart.setOption(option)
    }
  }

}
</script>
