import http from '@http/http'
export const _getUserInfo = (errMsg) => http.GET('/api/auth/userInfo', {}, errMsg)

export const userLogin = (user) => http.POST('./api/user/login', user) // 登录页面
export const selectNameBySn = (user) => http.GET('./api/user/selectNameBySn', user)
export const userPageList = (user) => http.GET('./api/user/userPageList', user)
export const userRemoveById = (user) => http.GET('./api/user/userRemoveById', user)
export const userRemoveByIds = (user) => http.POST('./api/user/userRemoveByIds', user)

export const userUpdate = (user) => http.POST('./api/user/userUpdate', user)
export const userInsert = (user) => http.POST('./api/user/userInsert', user)
export const exportStudentTemp = (user) => http.EXPORT('./api/user/exportStudentTemp', user)
export const exportHouseparentTemp = (user) => http.EXPORT('./api/user/exportHouseparentTemp', user)
export const exportCounsellorTemp = (user) => http.EXPORT('./api/user/exportCounsellorTemp', user)

