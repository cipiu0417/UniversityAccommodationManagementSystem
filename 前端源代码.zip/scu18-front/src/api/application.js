import http from '@http/http'

export const saveApplication = obj => http.POST('./api/application/save', obj)
export const getApplications = obj => http.GET('./api/application/pageList', obj)
export const getMaintainList = obj => http.GET('./api/maintainApplication/pageList', obj) // 显示不同用户能看到的维修申请列表
export const saveMaintainRecord = obj => http.POST('./api/maintainApplication/save', obj) // 学生提交维修申请
export const counsellorGetApplicationList = obj => http.GET('./api/user/counsellorGetApplicationList', obj)
export const counsellorCheck = obj => http.POST('./api/application/counsellorCheck', obj)
export const logInsert = obj => http.POST('./api/log/logInsert', obj)
export const stateChangeNo = obj => http.POST('./api/application/stateChangeNo', obj)

export const houseparentGetApplicationList = obj => http.GET('./api/user/houseparentGetApplicationList', obj)
export const stateChange = obj => http.POST('./api/application/stateChange', obj)

export const houseparentCheck = obj => http.POST('./api/application/houseparentCheck', obj)
