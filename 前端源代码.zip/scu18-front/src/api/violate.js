import http from '@http/http'
export const violateRecordInsert = (obj) => http.POST('./api/violateRecord/violateRecordInsert', obj)
export const violateRecordSelectById = (obj) => http.GET('./api/violateRecord/violateRecordSelectById', obj)
export const violateRecordSelectByRoomId = (obj) => http.GET('./api/violateRecord/violateRecordSelectByRoomId', obj)
export const pageList = (obj) => http.GET('./api/violateRecord/pageList', obj)
