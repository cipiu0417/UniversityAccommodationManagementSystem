import http from '@http/http'
// 图书分页查询
export const queryApartment = (query) => http.GET('./api/room/roomPageList', query)

export const deleteRoom = obj => http.GET('./api/room/roomRemoveById', obj)
export const deleteRooms = obj => http.POST('./api/room/roomRemoveByIds', obj)

export const updateRoom = obj => http.POST('./api/room/roomUpdate', obj)

export const exportRooms = obj => http.EXPORT('./api/room/exportRooms', obj)
export const exportTemp = () => http.EXPORT('./api/room/exportTemp')
export const addRoom = obj => http.POST('./api/room/roomInsert', obj)

export const getRoomId = obj => http.GET('./api/room/getRoomId', obj)
export const getById = obj => http.GET('./api/room/getById', obj) // 根据roomId查询room
