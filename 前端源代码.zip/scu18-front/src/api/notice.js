import http from '@http/http'

export const showList = obj => http.GET('./api/notice/pageList', obj) // 筛选显示公告列表
export const getContent = obj => http.GET('./api/notice/getContent', obj)
export const saveNotice = obj => http.POST('./api/notice/saveNotice', obj)
export const deleteById = obj => http.GET('./api/notice/deleteById', obj)
