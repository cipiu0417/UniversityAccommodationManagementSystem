import http from '@http/http'

export const checkinInsert = obj => http.POST('./api/checkin/checkinInsert', obj)
