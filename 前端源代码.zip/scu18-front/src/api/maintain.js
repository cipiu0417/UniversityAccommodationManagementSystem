import http from '@http/http'

export const getMaintainerList = () => http.GET('./api/user/getMaintainerList')
// export const saveMaintainRecord = obj => http.POST('./api/maintainRecord/saveRecord', obj)
export const assignMaintainer = obj => http.GET('./api/maintainApplication/assignMaintainer', obj)

export const showList = obj => http.GET('./api/maintainApplication/showList', obj) // 维修员查看等待维修列表
export const getName = obj => http.GET('./api/maintainRecord/getName', obj)
export const maintainComplete = obj => http.POST('./api/maintainApplication/maintainComplete', obj)

export const pageList = obj => http.GET('./api/maintainApplication/pageList', obj) // 显示不同用户能看到的维修申请列表
