import http from '@http/http'

export const sanitationRecordPageList = obj => http.GET('./api/sanitationRecord/sanitationRecordPageList', obj)
export const sanitationRecordInsert = obj => http.POST('./api/sanitationRecord/sanitationRecordInsert', obj)

export const weekNumber = obj => http.GET('./api/sanitationRecord/weekNumber', obj)
export const selectScoresByWeek = obj => http.GET('./api/sanitationRecord/selectScoresByWeek', obj)
export const sanitationRecordSelectById = obj => http.GET('./api/sanitationRecord/sanitationRecordSelectById', obj)
