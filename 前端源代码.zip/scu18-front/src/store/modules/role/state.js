export default {
  roleTypeMap: {
    1: {
      roleName: '学生'
    },
    2: {
      roleName: '辅导员'
    },
    3: {
      roleName: '宿舍管理员'
    },
    4: {
      roleName: '维修管理员'
    },
    5: {
      roleName: '超级管理员'
    }
  }
}
