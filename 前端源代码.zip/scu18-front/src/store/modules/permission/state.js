export default {
  // 配置白名单路由
  whiteList: ['/', 'notFound', 'login', 'forbidden', 'badGateway'],
  permissionMap: {
    1: {
      main: [
        'accommodation',
        'apartment',
        'sanVisualization',
        'notice',
        'noticeDetail',
        'personinfo',
        'stuViolation',
        'registration'
      ]
    },
    2: {
      main: [
        'approval',
        'apartment',
        'sanVisualization',
        'noticeDetail',
        'notice',
        'violationList'
      ]
    },
    3: {
      main: [
        'approval',
        'apartment',
        'noticeDetail',
        'sanitation',
        'sanVisualization',
        'notice',
        'postNotice',
        'violationManage',
        'assignment'
      ]
    },
    4: {
      main: ['maintainList']
    },
    5: {
      main: [
        'apartment',
        'userManage',
        'sanVisualization',
        'notice',
        'noticeDetail',
        'violationList',
        'maintainList'
      ]
    }
  }
}
