export default {
  id: null,
  sn: '',
  name: '',
  type: null
}
