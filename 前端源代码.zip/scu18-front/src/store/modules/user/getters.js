export default {
  getUserId: state => state.id,
  getUserSn: state => state.sn,
  getUserName: state => state.name,
  getUserType: state => state.type
}
