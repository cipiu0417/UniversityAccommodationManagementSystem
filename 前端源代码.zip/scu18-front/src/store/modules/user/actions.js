import { _getUserInfo } from '@api/user'
import types from './types'
export default {
  async fetchUserInfo ({ commit }) {
    // 导入api包中的user.js并用封装好的对象发了请求：http.GET('/api/auth/userInfo', {}, errMsg)
    let res = await _getUserInfo()
    if (res.status) {
      // 将当前登录用户存入缓存
      commit(types.SET_USER_ID, res.data.id)
      commit(types.SET_USER_SN, res.data.sn)
      commit(types.SET_USER_NAME, res.data.name)
      commit(types.SET_USER_TYPE, res.data.userType)
    }
    return res
  },
  async clearUserInfo ({ commit }) {
    // 将当前登录用户信息全部清空
    commit(types.SET_USER_ID, null)
    commit(types.SET_USER_SN, null)
    commit(types.SET_USER_NAME, null)
    commit(types.SET_USER_TYPE, null)
  }
}
