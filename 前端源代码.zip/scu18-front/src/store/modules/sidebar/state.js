// 菜单栏和可以访问的路由应该一致
// 每配置一个角色都需要配置相应的菜单栏和路由
export default {
  sidebarMap: {
    5: {
      main: [
        {
          groupTitle: '超管显示菜单'
        },
        {
          path: '/main/apartment/apartment',
          icon: 'el-icon-school',
          title: '公寓信息'
        },
        {
          path: '/main/admin/userManage',
          icon: 'el-icon-user',
          title: '用户管理'
        },
        {
          path: '/main/dormitory',
          icon: 'el-icon-s-home',
          title: '寝室信息',
          group: 'dormitory',
          children: [
            {
              path: '/main/dormitory/sanVisualization',
              icon: 'el-icon-s-unfold',
              title: '寝室卫生'
            }, {
              path: '/main/dormitory/notice',
              icon: 'el-icon-s-unfold',
              title: '公告栏'
            }, {
              path: '/main/dormitory/violationList',
              title: '寝室违纪情况',
              icon: 'el-icon-s-unfold'
            }
          ]
        },
        {
          path: '/main/maintain',
          icon: 'el-icon-suitcase',
          title: '维修管理'
        }
      ]
    },
    1: {
      main: [
        {
          groupTitle: '学生显示菜单'
        },
        {
          path: '/main/accommodation/accommodation',
          icon: 'el-icon-s-claim',
          title: '住宿申请'
        },
        {
          path: '/main/apartment/apartment',
          icon: 'el-icon-search',
          title: '公寓查询'
        },
        {
          path: '/main/dormitory',
          icon: 'el-icon-s-home',
          title: '寝室管理',
          group: 'dormitory',
          children: [
            {
              path: '/main/dormitory/sanVisualization',
              title: '寝室卫生',
              icon: 'el-icon-s-unfold'
            }, {
              path: '/main/dormitory/notice',
              title: '公告栏',
              icon: 'el-icon-s-unfold'
            }, {
              path: '/main/dormitory/personinfo',
              title: '个人通知',
              icon: 'el-icon-s-unfold'
            }, {
              path: '/main/dormitory/stuViolation',
              title: '违纪情况',
              icon: 'el-icon-s-unfold'
            }
          ]
        },
        {
          path: '/main/maintain/registration',
          icon: 'el-icon-attract',
          title: '维修信息登记'
        }
      ]
    },
    2: {
      main: [
        {
          groupTitle: '辅导员显示菜单'
        },
        {
          path: '/main/accommodation/approval',
          icon: 'el-icon-s-claim',
          title: '住宿申请审批'
        },
        {
          path: '/main/apartment/apartment',
          icon: 'el-icon-search',
          title: '公寓查询'
        },
        {
          path: '/main/dormitory',
          icon: 'el-icon-school',
          title: '寝室管理',
          group: 'dormitory',
          children: [
            {
              path: '/main/dormitory/sanVisualization',
              icon: 'el-icon-s-unfold',
              title: '寝室卫生'
            }, {
              path: '/main/dormitory/notice',
              title: '公告栏',
              icon: 'el-icon-s-unfold'
            }, {
              path: '/main/dormitory/violationList',
              title: '寝室违纪情况',
              icon: 'el-icon-s-unfold'
            }
          ]
        }
      ]
    },
    3: {
      main: [
        {
          groupTitle: '宿舍管理员显示菜单'
        },
        {
          path: '/main/accommodation/approval',
          icon: 'el-icon-s-claim',
          title: '住宿申请审批'
        },
        {
          path: '/main/apartment/apartment',
          icon: 'el-icon-school',
          title: '公寓管理'
        },
        {
          path: '/main/dormitory',
          icon: 'el-icon-date',
          title: '寝室管理',
          group: 'dormitory',
          children: [
            {
              path: '/main/dormitory/sanitation',
              icon: 'el-icon-s-unfold',
              title: '卫生管理'
            },
            {
              path: '/main/dormitory/sanVisualization',
              icon: 'el-icon-s-unfold',
              title: '寝室卫生'
            }, {
              path: '/main/dormitory/notice',
              icon: 'el-icon-s-unfold',
              title: '公告管理'
            }, {
              path: '/main/dormitory/postNotice',
              icon: 'el-icon-s-unfold',
              title: '发布公告'
            }, {
              path: '/main/dormitory/violationManage',
              icon: 'el-icon-s-unfold',
              title: '违纪管理'
            }
          ]
        },
        {
          path: '/main/maintain/assignment',
          icon: 'el-icon-thumb',
          title: '维修人员分配'
        }
      ]
    },
    4: {
      main: [
        {
          groupTitle: '维修管理员显示菜单'
        },
        {
          path: '/main/maintain/maintainList',
          icon: 'el-icon-suitcase',
          title: '维修列表'
        }
      ]
    }
  },
  sidebarTheme: {
    dark: {
      background: '#1f2c35',
      text: '#ffffff',
      activeText: '#ffffff'
    },
    light: {
      background: '#ffffff',
      text: '#000000',
      activeText: '#1890ff'
    }
  }
}
