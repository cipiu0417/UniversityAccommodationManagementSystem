import Vue from 'vue'
import Router from 'vue-router'
import NProgress from 'nprogress'
import permission from './permission'
import store from '../store/'
import { clearHttpRequestingList } from '@http/httpRequestList'
import routes from './routes'

Vue.$httpRequestList = []
Vue.use(Router)

let router = new Router({
  routes
})
// 每次路由跳转都到这
// 先看去的地方需不需要登录，不需要登录直接过去，需要登录看前端有没有当前登录信息，
// 前端有登录信息，验证权限然后过去；前端没有登录信息，去后端拿
// 后端拿到了，验证权限然后过去；拿不到，不让过去
router.beforeEach((to, from, next) => {
  if (to.meta.keepAlive) {
    store.commit('routecache/keepAlive', to.name)
  }
  clearHttpRequestingList()
  // 进度开始
  NProgress.start()
  // store是浏览器缓存的一种技术，从../store/导入
  // src/store/modules/permission/state.js，配置白名单路由有哪些，配置每个角色能访问哪些路由
  const whiteList = store.getters['permission/getWhiteList']
  // 判断去的地方是否属于白名单
  if (whiteList.indexOf(to.name) > -1 || whiteList.indexOf(to.path) > -1) {
    // 属于白名单直接放走
    next()
  } else if (!store.getters['user/getUserId']) {
    // 前端从缓存中没拿到，就向后端发请求并将当前用户的登录信息存入缓存
    store.dispatch('user/fetchUserInfo').then(res => {
      if (res.status) {
        // 权限校验
        permission(store, routes, to, next)
      } else {
        // 后端也拿不到，要么显示错误信息，要么去登录页面
        switch (res.code) {
          case -500:
            next({ name: 'badGateway' })
            break
          case 70005:
            next({ name: 'login' })
            break
        }
      }
    })
  } else {
    // 权限校验
    permission(store, routes, to, next)
  }
})
router.afterEach(() => {
  // 进度结束
  NProgress.done()
})
export default router
