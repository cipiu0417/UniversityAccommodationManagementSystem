// 配置路由的地方
const loginPage = [
  {
    path: '/login',
    name: 'login',
    component: () =>
      import('../pages/login/Login')
  }
]

const mainPage = [
  {
    path: '/',
    // 配置主页面
    redirect: '/login'
  },
  {
    path: '/main',
    name: 'main',
    component: () =>
      import('../pages/main/Main'),
    children: [
      {
        path: 'apartment/apartment',
        name: 'apartment',
        component: () =>
            import(
              '../pages/main/routes/apartment/Apartment'
            )
      },
      {
        path: 'accommodation/accommodation',
        name: 'accommodation',
        component: () =>
          import(
            '../pages/main/routes/accommodation/Accommodation'
          )
      },
      {
        path: 'accommodation/approval',
        name: 'approval',
        component: () =>
            import(
              '../pages/main/routes/accommodation/Approval'
            )
      },
      {
        path: 'apartment/addRoom',
        name: 'addRoom',
        component: () =>
            import(
              '../pages/main/routes/apartment/AddRoom'
            )
      },
      {
        path: 'dormitory/notice',
        name: 'notice',
        component: () =>
          import(
            '../pages/main/routes/dormitory/Notice'
          )
      },
      {
        path: 'dormitory/personinfo',
        name: 'personinfo',
        component: () =>
            import(
              '../pages/main/routes/dormitory/Personinfo'
            )
      },
      {
        path: 'dormitory/sanitation',
        name: 'sanitation',
        component: () =>
            import(
              '../pages/main/routes/dormitory/Sanitation'
            )
      },
      {
        path: 'dormitory/violationList',
        name: 'violationList',
        component: () =>
            import(
              '../pages/main/routes/dormitory/ViolationList'
            )
      },
      {
        path: 'dormitory/violationManage',
        name: 'violationManage',
        component: () =>
            import(
              '../pages/main/routes/dormitory/ViolationManage'
            )
      },
      {
        path: 'dormitory/stuViolation',
        name: 'stuViolation',
        component: () =>
            import(
              '../pages/main/routes/dormitory/StuViolation'
            )
      },
      {
        path: 'dormitory/noticeDetail',
        name: 'noticeDetail',
        component: () =>
            import(
              '../pages/main/routes/dormitory/NoticeDetail'
            )
      },
      {
        path: 'dormitory/postNotice',
        name: 'postNotice',
        component: () =>
            import(
              '../pages/main/routes/dormitory/PostNotice'
            )
      },
      {
        path: 'dormitory/sanVisualization',
        name: 'sanVisualization',
        component: () =>
            import(
              '../pages/main/routes/dormitory/SanVisualization'
            )
      },
      {
        path: 'maintain/registration',
        name: 'registration',
        component: () =>
          import(
            '../pages/main/routes/maintain/Registration'
          )
      },
      {
        path: 'maintain/assignment',
        name: 'assignment',
        component: () =>
          import(
            '../pages/main/routes/maintain/Assignment'
          )
      },
      {
        path: 'maintain/maintainList',
        name: 'maintainList',
        component: () =>
            import(
              '../pages/main/routes/maintain/MaintainList'
            )
      },
      {
        path: 'admin/userManage',
        name: 'userManage',
        component: () =>
            import(
              '../pages/main/routes/admin/UserManage'
            )
      }
    ]
  }
]

const errorPage = [
  {
    path: '/notFound',
    name: 'notFound',
    component: () =>
      import(/* webpackChunkName: "NotFound" */ '../pages/error/NotFound')
  },
  {
    path: '/forbidden',
    name: 'forbidden',
    component: () =>
      import(/* webpackChunkName: "Forbidden" */ '../pages/error/Forbidden')
  },
  {
    path: '/badGateway',
    name: 'badGateway',
    component: () =>
      import(/* webpackChunkName: "BadGateway" */ '../pages/error/BadGateway')
  },
  {
    path: '*',
    redirect: '/notFound'
  }
]
export default [...loginPage, ...mainPage, ...errorPage]
