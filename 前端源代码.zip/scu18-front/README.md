## Build Setup

``` bash
# 第一步：安装环境所需依赖
npm install

# 第二步：启动mock(port: 3001)
grunt

# 开发环境 (port:3000)
npm run dev

# 待发布环境（线上测试环境）
npm run build:sit

# 生产环境
npm run build
```
