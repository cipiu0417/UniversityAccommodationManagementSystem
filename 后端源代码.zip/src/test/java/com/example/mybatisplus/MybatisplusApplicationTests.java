//package com.example.mybatisplus;
//
//import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
//import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
//import com.example.mybatisplus.mapper.AdminMapper;
//import com.example.mybatisplus.mapper.BookMapper;
//import com.example.mybatisplus.model.domain.Admin;
//import com.example.mybatisplus.model.domain.Book;
//import com.example.mybatisplus.model.domain.Room;
//import com.example.mybatisplus.service.BookService;
//import com.example.mybatisplus.service.RoomService;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.Arrays;
//import java.util.List;
//
//@SpringBootTest
//class MybatisplusApplicationTests {
//
//    // 引用
//    @Autowired //请求注入
//    private AdminMapper adminMapper;
//    //private RoomService roomService;
//    // 认为ioc容器中没有这个实例对象
//    // 但运行不会报错
//    // 因为直接通过MapperScan注解添加进来，所以是存在的
//    // 报错不影响运行可以不解决
//    // 如果非要解决就加注解Repository
//
//    @Test //测试程序用Test注解
//    public void hh() {
//        System.out.println(adminMapper);
//        // 在数据库中查找id为1的admin
//        // 方法一：用别人写好的接口
//        // 包括单表的所有增删改查
//        Admin admin = adminMapper.selectById(1);
//        System.out.println(admin);
//        // 方法二：自己写sql
//    }
//
//    // 增
//    @Test
//    public void hh1() {
//        Room room = new Room();
//        room.setCampus("西园13舍");
//        roomService.insert(room);
//
//    }
//
//    // 删
//    @Test
//    public void hh2() {
////        adminMapper.deleteById(50);
//        // 条件构造器
//        QueryWrapper<Book> wrapper = new QueryWrapper<>();
//        wrapper.between("id", 104, 203);
//        bookMapper.delete(wrapper);
//    }
//
//    // 改
//    @Test
//    public void hh3() {
//       /* Admin admin = new Admin();
//        admin.setId(50L).setLoginName("hello");
//        adminMapper.updateById(admin);*/
//       Room room = new Room();
//       room.setId(20L).setCampus("东园9舍");
//       roomService.update(room);
//    }
//
//    // 查
//    @Test
//    public void hh4() {
//        QueryWrapper<Admin> wrapper = new QueryWrapper<>();
//        wrapper.eq("id", 50);
//        Admin admin = adminMapper.selectOne(wrapper);
//        System.out.println(admin);
//
//        // 查所有记录
//        adminMapper.selectList(null);
//        // 分页,每页多少条，页码是多少
//        Integer pageNo = 1;
//        Integer pageSize = 10;
//        // 构建分页器
//        Page<Admin> page = new Page<>();
//        page.setCurrent(pageNo);
//        page.setSize(pageSize);
//        Page<Admin> adminPage = adminMapper.selectPage(page, null);
//        System.out.println(adminPage);
//    }
//
//    // mybatis就是为了在java中调用sql
//    // 利用自定义方法查询数据库，需要自己为mapper写接口，接口中的sql语句写在xml文件中
//    @Test
//    public void hh6() {
//        Admin admin =  adminMapper.mySelectById(1L);
//        System.out.println(admin);
//    }
//
//    // 自定义sql分页查询
//    @Test
//    public void hh7() {
//        // 分页器不可少
//        Integer pageNo = 1;
//        Integer pageSize = 10;
//        Page<Admin> page = new Page<>(pageNo,pageSize);
//        // 把分页器传递到接口并返回
//        Admin admin = new Admin();
//        admin.setLoginName("zhang");
//        page = adminMapper.pageList(page, admin);
//        System.out.println(page.getTotal());
//    }
//
//    // 动态sql
//    // 涉及到最常用的<where><if><forEach>标签
//    @Autowired
//    private BookMapper bookMapper;
//    @Test
//    public void hh8() {
//        // 根据前端传来的字段在book中插入多条记录
//        // insert into book(name,author) values (?, ?)
//        // 模拟前端传来数据
//        Book book1 = new Book().setAuthor("罗贯中").setName("西游记");
//        Book book2 = new Book().setAuthor("曹雪芹").setName("红楼梦");
//        Book book3 = new Book().setAuthor("张三").setName("三国演义");
//        List<Book> list = Arrays.asList(book1,book2,book3);
//        bookMapper.myInsert(list);
//    }
//
//    @Test
//    public void hh9() {
//        // 根据前端传来的字段在book中查询符合条件的记录，并分页显示
//        // select * from book where (?, ?, ?)
//        // 模拟前端传来数据
//        Book book = new Book().setAuthor("张三");
//        Integer pageNo = 1;
//        Integer pageSize = 10;
//        Page<Book> page = new Page<>(pageNo,pageSize);
//        page = bookMapper.mySelect(page,book);//注意返回值是Page对象
//        System.out.println(page.getTotal());
//    }
//
//    @Autowired
//    RoomService roomService;
//    @Test
//    public void hh10() {
//        // 批量删除
//        // delete * from book where id in (?,?,?)
//        List<Long> list = Arrays.asList(5L,6L,7L);
//        roomService.roomRemoveByIds(list);
//    }
//
//    // 关联查询怎么映射 开发经常遇到的场景
//    @Test
//    public void hh11() {
//        Book book = bookMapper.selectById(2);
//        Admin admin = adminMapper.selectById(book.getCreatorId());
//        // 在Book类中添加一个Admin字段，但是在mybatis-plus中，所有的实体属性会被当成数据库表的查询字段
//        book.setAdmin(admin);
//        System.out.println(book);
//        // 会报错提示book数据库中没有admin字段
//
//        Book book1 = bookMapper.selectByIdWithAdmin(2);
//        System.out.println(book1);
//    }
//
//}
