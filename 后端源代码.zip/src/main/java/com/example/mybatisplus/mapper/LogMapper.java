package com.example.mybatisplus.mapper;

import com.example.mybatisplus.model.domain.Log;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
@Repository
public interface LogMapper extends BaseMapper<Log> {

    List<Log> getLog(@Param("appId") Long appId);
}
