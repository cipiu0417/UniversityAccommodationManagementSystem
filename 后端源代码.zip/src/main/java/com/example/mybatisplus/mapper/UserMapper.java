package com.example.mybatisplus.mapper;

import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-25
 */
@Repository
public interface UserMapper extends BaseMapper<User> {

    Object getHouseparentSn(@Param("sn") String sn);

    List<Application> counsellorGetApplicationList(@Param("sn") String sn);

    List<Application> houseparentGetApplicationList(@Param("sn") String sn);

    boolean mydeleteById(@Param("id") Long id);

    boolean mydeleteByIds(@Param("ids") List<Long> ids);
}
