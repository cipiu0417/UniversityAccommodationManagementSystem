package com.example.mybatisplus.mapper;

import com.example.mybatisplus.model.domain.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Repository
public interface NoticeMapper extends BaseMapper<Notice> {

}
