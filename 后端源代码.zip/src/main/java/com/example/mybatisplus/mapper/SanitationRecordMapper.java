package com.example.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.SanitationRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Repository
public interface SanitationRecordMapper extends BaseMapper<SanitationRecord> {
    boolean myDeleteById(@Param("id")Long id);

    IPage<SanitationRecord> pageList1(Page page, User user);

    IPage<SanitationRecord> pageList3(Page page, User user);

    IPage<SanitationRecord> selectByRoomId(@Param("page") Page page,@Param("roomId") Long roomId);

}
