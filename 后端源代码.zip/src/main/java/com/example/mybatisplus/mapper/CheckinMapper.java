package com.example.mybatisplus.mapper;

import com.example.mybatisplus.model.domain.Checkin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
@Repository
public interface CheckinMapper extends BaseMapper<Checkin> {
    //自定义删除方法
    boolean mydeleteById(@Param("id") Long id);
}
