package com.example.mybatisplus.mapper;

import com.example.mybatisplus.model.domain.Application;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mybatisplus.model.domain.Log;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
@Repository
public interface ApplicationMapper extends BaseMapper<Application> {

    boolean stateChange(@Param("application") Application application);

    boolean stateChangeNo(@Param("application") Application application);

    boolean counsellorCheck(@Param("application") Application application);

    boolean houseparentCheck(@Param("application") Application application);
}
