package com.example.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.MaintainApplication;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Repository
public interface MaintainApplicationMapper extends BaseMapper<MaintainApplication> {

    IPage<MaintainApplication> pageList1(Page pageDTO, @Param("user") User user);

    IPage<MaintainApplication> pageList3( Page pageDTO, @Param("user") User user);

    Object getName(@Param("applicationId") Long applicationId);
}
