package com.example.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.MaintainRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mybatisplus.model.domain.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Repository
public interface MaintainRecordMapper extends BaseMapper<MaintainRecord> {

    IPage<MaintainRecord> showList(@Param("page") Page page, @Param("user") User user);

    IPage<MaintainRecord> showHistoryList(@Param("page") Page page, @Param("user") User user);

    Object getName(@Param("applicationId") Long applicationId);
}
