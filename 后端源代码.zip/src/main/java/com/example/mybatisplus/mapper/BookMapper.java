package com.example.mybatisplus.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Book;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lxp
 * @since 2023-06-17
 */
@Repository
public interface BookMapper extends BaseMapper<Book> {

    void myInsert(@Param("list")List<Book> list);

    Page<Book> mySelect(@Param("page") Page<Book> page, @Param("book") Book book);

    void myDelete(@Param("list") List<Long> list);

    Book selectByIdWithAdmin(@Param("id") Integer i);
}
