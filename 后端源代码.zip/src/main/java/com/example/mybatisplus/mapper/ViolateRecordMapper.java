package com.example.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.domain.ViolateRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Repository
public interface ViolateRecordMapper extends BaseMapper<ViolateRecord> {

    boolean myDeleteById(Long id);

    IPage<ViolateRecord> pageList1(Page page, User user);

    IPage<ViolateRecord> pageList2(Page page, User user);

    IPage<ViolateRecord> pageList3(Page page, User user);

    IPage<ViolateRecord> selectByRoomId(@Param("page")Page page,@Param("roomId") Long roomId);
}
