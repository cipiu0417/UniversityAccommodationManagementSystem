package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Notice;
import com.example.mybatisplus.mapper.NoticeMapper;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.NoticeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Service
public class NoticeServiceImpl extends ServiceImpl<NoticeMapper, Notice> implements NoticeService {

    @Autowired
    private NoticeMapper noticeMapper;

    @Override
    public Object saveNotice(Notice notice) {
        return noticeMapper.insert(notice);
    }

    @Override
    public Page<Notice> pageList(PageDTO pageDTO, Notice notice) {
        Page<Notice> page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        QueryWrapper<Notice> wrapper = new QueryWrapper<>();
        if(StringUtils.isNotBlank(notice.getTitle())) {
            wrapper.like("title", notice.getTitle());
        }
        if(StringUtils.isNotBlank(notice.getContent())) {
            wrapper.like("content", notice.getContent());
        }
        wrapper.eq("is_deleted", 0);
        wrapper.orderByDesc("create_time");
        Page<Notice> noticePage = noticeMapper.selectPage(page, wrapper);
        return noticePage;
    }

    @Override
    public int deleteById(Long id) {
        UpdateWrapper<Notice> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", id);
        wrapper.setSql("is_deleted = 1");
        int update = noticeMapper.update(null, wrapper);
        return update;
    }

    @Override
    public Object getContent(Long id) {
        return noticeMapper.selectById(id);
    }
}
