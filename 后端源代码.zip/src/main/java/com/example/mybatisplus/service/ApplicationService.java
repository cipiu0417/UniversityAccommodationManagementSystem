package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Application;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.domain.Log;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
public interface ApplicationService extends IService<Application> {
//    Page<Application> applicationPageList(PageDTO pageDTO, Application application);

    int insert(Application application);

    Page<Application> pageList(PageDTO pageDTO, User user);

    boolean stateChange(Application application);

    boolean stateChangeNo(Application application);

    boolean counsellorCheck(Application application);

    boolean houseparentCheck(Application application);
}
