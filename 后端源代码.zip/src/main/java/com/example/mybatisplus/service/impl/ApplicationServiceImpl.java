package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.mapper.ApplicationMapper;
import com.example.mybatisplus.model.domain.Log;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.ApplicationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
@Service
public class ApplicationServiceImpl extends ServiceImpl<ApplicationMapper, Application> implements ApplicationService {

    @Autowired
    private ApplicationMapper applicationMapper;

//    @Override
//    public Page<Application> applicationPageList(PageDTO pageDTO, Application application) {
//        Page<Application> page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
//        QueryWrapper<Application> wrapper = new QueryWrapper<>();
//        wrapper.eq("sn", application.getSn());
//        wrapper.eq("is_deleted", 0);
//        Page<Application> applicationPage = applicationMapper.selectPage(page, wrapper);
//        return applicationPage;
//    }

    @Override
    public int insert(Application application) {
        int insert = applicationMapper.insert(application);
        return insert;
    }

    @Override
    // 注意传参的时候user的roleType不能为空
    public Page<Application> pageList(PageDTO pageDTO, User user) {
        Page<Application> page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        QueryWrapper<Application> wrapper = new QueryWrapper<>();
        // 只有超级管理员能看到所有申请
        Integer roleType = user.getRoleType();
        if (roleType != 5) {
            wrapper.eq("sn", user.getSn());
        }
        wrapper.eq("is_deleted", 0);
        Page<Application> applicationPage = applicationMapper.selectPage(page, wrapper);
        return applicationPage;
    }

    @Override
    public boolean stateChange(Application application) {
        return applicationMapper.stateChange(application);
    }

    @Override
    public boolean stateChangeNo(Application application) {
        return applicationMapper.stateChangeNo(application);
    }

    @Override
    public boolean counsellorCheck(Application application) {
        return applicationMapper.counsellorCheck(application);
    }

    @Override
    public boolean houseparentCheck(Application application) {
        return applicationMapper.houseparentCheck(application);
    }
}
