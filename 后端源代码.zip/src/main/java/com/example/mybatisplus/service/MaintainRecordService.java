package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.mybatisplus.model.domain.MaintainRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
public interface MaintainRecordService extends IService<MaintainRecord> {

    Object saveRecord(MaintainRecord maintainRecord);

    IPage<MaintainRecord> showList(PageDTO pageDTO, User user);

    IPage<MaintainRecord> showHistoryList(PageDTO pageDTO, User user);

    Object maintainComplete(MaintainRecord maintainRecord);

    Object getName(Long applicationId);
}
