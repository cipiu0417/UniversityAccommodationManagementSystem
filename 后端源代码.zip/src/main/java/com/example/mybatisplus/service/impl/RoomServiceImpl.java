package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.common.utls.ExcelUtil;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.Room;
import com.example.mybatisplus.mapper.RoomMapper;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.RoomService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-25
 */

@Service
public class RoomServiceImpl extends ServiceImpl<RoomMapper, Room> implements RoomService {

    @Autowired
    private RoomMapper roomMapper;

    @Override
    public Page<Room> roomPageList(PageDTO pageDTO, Room room) {
        Page<Room> page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        QueryWrapper<Room> wrapper = new QueryWrapper<>();
        if(StringUtils.isNotBlank(room.getCampus())) {
            wrapper.like("campus", room.getCampus());
        }
        if(StringUtils.isNotBlank(room.getBuilding())) {
            wrapper.like("building", room.getBuilding());
        }
        if(room.getSize() != null) {
            wrapper.eq("size", room.getSize());
        }
        if(StringUtils.isNotBlank(room.getGender())) {
            wrapper.eq("gender", room.getGender());
        }
        if(room.getRent1() != null && room.getRent2() != null) {
            wrapper.between("rent", room.getRent1(), room.getRent2());
        }
        else if(room.getRent1() != null) {
            wrapper.gt("rent", room.getRent1());
        }
        else if(room.getRent2() != null) {
            wrapper.lt("rent",room.getRent2());
        }
        wrapper.eq("is_deleted", 0);
        Page<Room> roomPage = roomMapper.selectPage(page, wrapper);
        return roomPage;
    }

    @Override
    public boolean roomRemoveById(Long id) {
        return roomMapper.mydeleteById(id);
    }

    @Override
    public boolean roomRemoveByIds(List<Long> ids) {
        return roomMapper.mydeleteByIds(ids);
    }

    @Override
    public void insert(Room room) {
        roomMapper.insert(room);
        return ;
    }

    @Override
    public void update(Room room) {
        roomMapper.updateById(room);
        return ;
    }

    @Override
    public void exportRooms(HttpServletResponse response, Room room){
        QueryWrapper<Room> wrapper = new QueryWrapper<>();
        //条件查询
        if(StringUtils.isNotBlank(room.getCampus())){
            wrapper.like("campus",room.getCampus());
        }
        if(StringUtils.isNotBlank(room.getBuilding())){
            wrapper.like("building",room.getBuilding());
        }
        if(room.getSize() != null) {
            wrapper.eq("size", room.getSize());
        }
        if(StringUtils.isNotBlank(room.getGender())) {
            wrapper.eq("gender", room.getGender());
        }
        //获取所有房间
        List<Room> rooms = roomMapper.selectList(wrapper);
        try {
            ExcelUtil.exportRooms(response,rooms);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void exportTemp(HttpServletResponse response) {
        try{
            ExcelUtil.exportTemp(response);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public JsonResponse importRooms(List<String[]> list) {
        List<String> error = new ArrayList<>();
        List<Room> rooms = new ArrayList<>();
        for(int i=1;i<list.size();i++){
            //数据验证 判断这个数据是否已经存在 如果存在提示报错
            try{
                Room room = new Room().setCampus(list.get(i)[0])
                        .setBuilding(list.get(i)[1])
                        .setFloor(Integer.valueOf(list.get(i)[2]))
                        .setRoomNumber(list.get(i)[3])
                        .setGender(list.get(i)[4])
                        .setRent(Integer.valueOf(list.get(i)[5]))
                        .setSize(Integer.valueOf(list.get(i)[6]));
                rooms.add(room);
            } catch (Exception e){
                error.add("第"+(i+1)+"行数据出现问题："+e.getMessage());
            }
        }
        //批量插入
        Map<String,Object> map = new HashMap<>();
        if(error.size()>0){
            map.put("error",error);
            return JsonResponse.success(map);
        }
        this.saveBatch(rooms);
        map.put("success","成功导入"+rooms.size()+"条数据");
        return JsonResponse.success(map);
    }


    @Override
    public Object getRoomId(Application application) {
        Map<String, Object> map = new HashMap<>();
        map.put("campus", application.getCampus());
        map.put("building", application.getBuilding());
        map.put("room_number", application.getRoomNumber());
        return roomMapper.selectByMap(map);
    }
}
