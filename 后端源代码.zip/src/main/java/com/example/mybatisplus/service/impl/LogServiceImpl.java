package com.example.mybatisplus.service.impl;

import com.example.mybatisplus.model.domain.Log;
import com.example.mybatisplus.mapper.LogMapper;
import com.example.mybatisplus.service.LogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
@Service
public class LogServiceImpl extends ServiceImpl<LogMapper, Log> implements LogService {

    @Autowired
    private LogMapper logMapper;


    @Override
    public int insert(Log log) {
        // 将审核记录存入log
        return logMapper.insert(log);
    }

    @Override
    public List<Log> getLog(Long appId) {
        return logMapper.getLog(appId);
    }
}
