package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.mybatisplus.model.domain.Checkin;
import com.example.mybatisplus.mapper.CheckinMapper;
import com.example.mybatisplus.service.CheckinService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
@Service
public class CheckinServiceImpl extends ServiceImpl<CheckinMapper, Checkin> implements CheckinService {

    @Autowired
    private CheckinMapper checkinMapper;
    @Override
    public boolean insert(Checkin checkin) {
        QueryWrapper<Checkin> wrapper = new QueryWrapper<>();
        wrapper.like("room_id",checkin.getRoomId());
        List<Checkin> list = checkinMapper.selectList(wrapper);
        if(list.size() == 4){
            return false;
        }else {
            checkinMapper.insert(checkin);
            return true;
        }

    }

    @Override
    public void update(Checkin checkin) {
        checkinMapper.updateById(checkin);
        return;
    }

    @Override
    public boolean checkinRemoveById(Long id) {
        return checkinMapper.mydeleteById(id);
    }
}
