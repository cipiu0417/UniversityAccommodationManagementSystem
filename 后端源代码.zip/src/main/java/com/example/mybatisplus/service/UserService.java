package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.dto.PageDTO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-25
 */
public interface UserService extends IService<User> {

    Object login(User user);

    Object getHouseparentSn(String sn);

    List<Application> counsellorGetApplicationList(String sn);

    List<Application> houseparentGetApplicationList(String sn);

    List<User> selectNameBySn(String sn);

    List<User> getMaintainerList();

    void exportStudentTemp(HttpServletResponse response);

    void exportHouseparentTemp(HttpServletResponse response);

    void exportCounsellorTemp(HttpServletResponse response);

    JsonResponse importUsers(List<String[]> list);

    Page<User> userPageList(PageDTO pageDTO, User user);

    boolean userRemoveById(Long id);

    boolean userRemoveByIds(List<Long> ids);

    void insert(User user);

    void update(User user);
}
