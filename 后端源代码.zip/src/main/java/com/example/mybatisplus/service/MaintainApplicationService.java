package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.mybatisplus.model.domain.MaintainApplication;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.domain.MaintainRecord;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
public interface MaintainApplicationService extends IService<MaintainApplication> {

    int insert(MaintainApplication maintainApplication);

    IPage<MaintainApplication> pageList(PageDTO pageDTO, User user);

    Object assignMaintainer(Long id, String maintainerSn);

    Object showList(PageDTO pageDTO, User user, String state);

//    Object showHistoryList(PageDTO pageDTO, User user);

    Object maintainComplete(MaintainApplication maintainApplication);

    Object getName(Long applicationId);
}
