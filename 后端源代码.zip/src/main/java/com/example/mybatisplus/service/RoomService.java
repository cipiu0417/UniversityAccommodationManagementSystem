package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.Room;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.dto.PageDTO;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-25
 */
public interface RoomService extends IService<Room> {

    Page<Room> roomPageList(PageDTO pageDTO, Room room);

    boolean roomRemoveById(Long id);

    boolean roomRemoveByIds(List<Long> ids);

    void insert(Room room);

    void update(Room room);

    void exportRooms(HttpServletResponse response, Room room) throws IOException;

    void exportTemp(HttpServletResponse response);

    JsonResponse importRooms(List<String[]> list);

    Object getRoomId(Application application);

}
