package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.common.utls.ExcelUtil;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.mapper.UserMapper;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-25
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public Object login(User user) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("sn", user.getSn()).eq("password", user.getPassword());
        User user1 = userMapper.selectOne(wrapper);
        return user1;
    }

    @Override
    public Object getHouseparentSn(String sn) {
        return userMapper.getHouseparentSn(sn);
    }

    @Override
    public List<Application> counsellorGetApplicationList(String sn) {
        return userMapper.counsellorGetApplicationList(sn);
    }

    @Override
    public List<Application> houseparentGetApplicationList(String sn) {
        return userMapper.houseparentGetApplicationList(sn);
    }

    @Override
    public List<User> selectNameBySn(String sn) {
        Map<String, Object> map = new HashMap<>();
        map.put("sn", sn);
        return userMapper.selectByMap(map);
    }

    @Override
    public List<User> getMaintainerList() {
        Map<String, Object> map = new HashMap<>();
        map.put("role_type", 4);
        return userMapper.selectByMap(map);
    }

    @Override
    public void exportStudentTemp(HttpServletResponse response) {
        try {
            ExcelUtil.exportStudentTemp(response);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void exportHouseparentTemp(HttpServletResponse response) {
        try {
            ExcelUtil.exportHouseparentTemp(response);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void exportCounsellorTemp(HttpServletResponse response) {
        try {
            ExcelUtil.exportCounsellorTemp(response);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public JsonResponse importUsers(List<String[]> list) {
        List<String> error = new ArrayList<>();
        List<User> users = new ArrayList<>();

        if(StringUtils.equals(list.get(1)[5],"类型")){
            //宿管信息导入
            for(int i=1;i<list.size();i++){
                try{
                    User user = new User().setSn(list.get(i)[0])
                            .setPassword(list.get(i)[1])
                            .setName(list.get(i)[2])
                            .setGender(Boolean.valueOf(list.get(i)[3]))
                            .setPhone(list.get(i)[4])
                            .setRoleType(Integer.valueOf(list.get(i)[5]));
                    users.add(user);
                } catch (Exception e){
                    error.add("第"+(i+1)+"行数据出现问题："+e.getMessage());
                }
            }
        }else if(StringUtils.equals(list.get(1)[6],"类型")){
            //辅导员信息导入
            for(int i=1;i<list.size();i++){
                try{
                    User user = new User().setSn(list.get(i)[0])
                            .setPassword(list.get(i)[1])
                            .setName(list.get(i)[2])
                            .setGender(Boolean.valueOf(list.get(i)[3]))
                            .setCollege(list.get(i)[4])
                            .setPhone(list.get(i)[5])
                            .setRoleType(Integer.valueOf(list.get(i)[6]));
                    users.add(user);
                } catch (Exception e){
                    error.add("第"+(i+1)+"行数据出现问题："+e.getMessage());
                }
            }
        }else if(StringUtils.equals(list.get(1)[8],"类型")){
            for(int i=1;i<list.size();i++){
                try{
                    User user = new User().setSn(list.get(i)[0])
                            .setPassword(list.get(i)[1])
                            .setName(list.get(i)[2])
                            .setGrade(list.get(i)[3])
                            .setGender(Boolean.valueOf(list.get(i)[4]))
                            .setCollege(list.get(i)[5])
                            .setCounsellorSn(list.get(i)[6])
                            .setPhone(list.get(i)[7])
                            .setRoleType(Integer.valueOf(list.get(i)[8]));
                    users.add(user);
                } catch (Exception e){
                    error.add("第"+(i+1)+"行数据出现问题："+e.getMessage());
                }
            }
        }


        //批量插入
        Map<String,Object> map = new HashMap<>();
        if(error.size()>0){
            map.put("error",error);
            return JsonResponse.success(map);
        }
        this.saveBatch(users);
        map.put("success","成功导入"+users.size()+"条数据");
        return JsonResponse.success(map);
    }

    @Override
    public Page<User> userPageList(PageDTO pageDTO, User user) {
        Page<User> page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        if(StringUtils.isNotBlank(user.getSn())){
            wrapper.like("sn",user.getSn());
        }
        if(StringUtils.isNotBlank(user.getPassword())){
            wrapper.like("password",user.getPassword());
        }
        if(StringUtils.isNotBlank(user.getName())){
            wrapper.like("name",user.getName());
        }
        if(StringUtils.isNotBlank(user.getGrade())){
            wrapper.like("grade",user.getGrade());
        }
        if(user.getGender() != null){
            wrapper.eq("gender",user.getGender());
        }
        if(StringUtils.isNotBlank(user.getCollege())){
            wrapper.like("college",user.getCollege());
        }
        if(StringUtils.isNotBlank(user.getCounsellorSn())){
            wrapper.like("counsellor_sn",user.getCounsellorSn());
        }
        if(StringUtils.isNotBlank(user.getPhone())){
            wrapper.like("phone",user.getPhone());
        }
        if(user.getRoleType() != null){
            wrapper.eq("role_type",user.getRoleType());
        }
        wrapper.eq("is_deleted",0);
        Page<User> userPage = userMapper.selectPage(page,wrapper);
        return userPage;
    }

    @Override
    public boolean userRemoveById(Long id) {
        return userMapper.mydeleteById(id);
    }

    @Override
    public boolean userRemoveByIds(List<Long> ids) {
        return userMapper.mydeleteByIds(ids);
    }

    @Override
    public void insert(User user) {
        userMapper.insert(user);
        return;
    }

    @Override
    public void update(User user) {
        userMapper.updateById(user);
        return;
    }
}
