package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.domain.ViolateRecord;
import com.example.mybatisplus.mapper.ViolateRecordMapper;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.ViolateRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Service
public class ViolateRecordServiceImpl extends ServiceImpl<ViolateRecordMapper, ViolateRecord> implements ViolateRecordService {

    @Autowired
    private ViolateRecordMapper violateRecordMapper;

    @Override
    public Page<ViolateRecord> violateRecordPageList(PageDTO pageDTO, ViolateRecord violateRecord) {
        Page<ViolateRecord> page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        QueryWrapper<ViolateRecord> wrapper = new QueryWrapper<>();
        if(violateRecord.getRoomId()!=null){
            wrapper.eq("room_id",violateRecord.getRoomId());
        }
        if(violateRecord.getDate()!=null){
            wrapper.eq("data",violateRecord.getDate());
        }
        if(StringUtils.isNotBlank(violateRecord.getContent())) {
            wrapper.like("content", violateRecord.getContent());
        }
        if(StringUtils.isNotBlank(violateRecord.getPunishment())){
            wrapper.eq("punishment",violateRecord.getPunishment());
        }
        if(StringUtils.isNotBlank(violateRecord.getHouseparentSn())){
            wrapper.eq("houseparent_sn",violateRecord.getHouseparentSn());
        }
        wrapper.eq("is_deleted",0);
        Page<ViolateRecord> violateRecordPage = violateRecordMapper.selectPage(page,wrapper);

        return violateRecordPage;
    }

    @Override
    public Object violateRecordSelectById(Long id) {
        ViolateRecord violateRecord = violateRecordMapper.selectById(id);
        return violateRecord;
    }

    @Override
    public IPage<ViolateRecord> violateRecordSelectByRoomId(PageDTO pageDTO,Long roomId) {
        Page page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        return violateRecordMapper.selectByRoomId(page,roomId);
    }

    @Override
    public boolean violateRecordRemoveById(Long id) {
        return violateRecordMapper.myDeleteById(id);
    }

    @Override
    public void insert(ViolateRecord violateRecord) {
        violateRecordMapper.insert(violateRecord);
        return;
    }

    @Override
    public void violateRecordUpdate(ViolateRecord violateRecord) {
        violateRecordMapper.updateById(violateRecord);
        return;
    }

    @Override
    public IPage<ViolateRecord> pageList(PageDTO pageDTO, User user) {
        Page page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        if(user.getRoleType()==1){
            //学生
            return violateRecordMapper.pageList1(page,user);
        }
        else if(user.getRoleType()==2){
            //辅导员
            return violateRecordMapper.pageList2(page,user);
        }
        else if(user.getRoleType()==3){
            //宿管
            return violateRecordMapper.pageList3(page,user);
        }
        return new Page<>();
    }


}
