package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.MaintainApplication;
import com.example.mybatisplus.mapper.MaintainApplicationMapper;
import com.example.mybatisplus.model.domain.MaintainRecord;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.MaintainApplicationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
//import org.jetbrains.annotations.NotNull;
//import com.sun.istack.internal.NotNull;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Service
public class MaintainApplicationServiceImpl extends ServiceImpl<MaintainApplicationMapper, MaintainApplication> implements MaintainApplicationService {

    @Autowired
    private MaintainApplicationMapper maintainApplicationMapper;


    @Override
    public int insert(MaintainApplication maintainApplication) {
        return maintainApplicationMapper.insert(maintainApplication);
    }

    @Override
    public IPage<MaintainApplication> pageList(PageDTO pageDTO, User user) {
        Page<Object> page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        if(user.getRoleType() == 1) {
            return maintainApplicationMapper.pageList1(page, user);
        }
        else if(user.getRoleType() == 3) {
            return maintainApplicationMapper.pageList3(page, user);
        }
        return  new Page<>();
    }

    @Override
    public Object assignMaintainer(Long id, String maintainerSn) {
        // 将progress修改为等待维修
        UpdateWrapper<MaintainApplication> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", id).set("progress", "等待维修").set("maintainer_sn", maintainerSn);
//        wrapper.setSql("progress = '等待维修');
        int update = maintainApplicationMapper.update(null, wrapper);
        return update;
    }

    @Override
    public Object showList(PageDTO pageDTO, User user, String state) {
        Page page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        QueryWrapper<MaintainApplication> wrapper = new QueryWrapper<>();
        if(StringUtils.equals(state, "等待维修")) {
            wrapper.eq("progress", "等待维修").eq("maintainer_sn", user.getSn());
        }
        else if(StringUtils.equals(state, "维修完成")) {
            wrapper.eq("progress", "维修完成").eq("maintainer_sn", user.getSn());
        }
        return maintainApplicationMapper.selectPage(page, wrapper);
    }

//    @Override
//    public Object showHistoryList(PageDTO pageDTO, User user) {
//        Page page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
//        QueryWrapper<MaintainApplication> wrapper = new QueryWrapper<>();
//        wrapper.eq("progress", "维修完成").eq("maintainer_sn", user.getSn());
//        return maintainApplicationMapper.selectPage(page, wrapper);
//    }

    @Override
    public Object maintainComplete(MaintainApplication maintainApplication) {
        // 将progress修改为维修完成
        UpdateWrapper<MaintainApplication> wrapper2 = new UpdateWrapper<>();
        wrapper2.eq("id", maintainApplication.getId());
        wrapper2.setSql("progress = '维修完成'");
        int update = maintainApplicationMapper.update(null, wrapper2);
        return update;
    }

    @Override
    public Object getName(Long applicationId) {
        return maintainApplicationMapper.getName(applicationId);
    }

}
