package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.mapper.MaintainApplicationMapper;
import com.example.mybatisplus.model.domain.MaintainApplication;
import com.example.mybatisplus.model.domain.MaintainRecord;
import com.example.mybatisplus.mapper.MaintainRecordMapper;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.MaintainRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Service
public class MaintainRecordServiceImpl extends ServiceImpl<MaintainRecordMapper, MaintainRecord> implements MaintainRecordService {

    @Autowired
    private MaintainRecordMapper maintainRecordMapper;

    @Autowired
    private MaintainApplicationMapper maintainApplicationMapper;

    @Override
    public Object saveRecord(MaintainRecord maintainRecord) {
        // 将status设置为等待维修
        maintainRecord.setStatus("等待维修");
        int insert = maintainRecordMapper.insert(maintainRecord);
        // 将progress修改为等待维修
        UpdateWrapper<MaintainApplication> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", maintainRecord.getApplicationId());
        wrapper.setSql("progress = '等待维修'");
        maintainApplicationMapper.update(null, wrapper);
        return insert;
    }

    @Override
    public IPage<MaintainRecord> showList(PageDTO pageDTO, User user) {
        Page page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        return maintainRecordMapper.showList(page, user);
    }

    @Override
    public IPage<MaintainRecord> showHistoryList(PageDTO pageDTO, User user) {
        Page page = new Page<>(pageDTO.getPageNo(), pageDTO.getPageSize());
        return maintainRecordMapper.showHistoryList(page, user);
    }

    @Override
    public Object maintainComplete(MaintainRecord maintainRecord) {
        // 将status修改为维修完成
        UpdateWrapper<MaintainRecord> wrapper1 = new UpdateWrapper<>();
        wrapper1.eq("id", maintainRecord.getId());
        wrapper1.setSql("status = '维修完成'");
        maintainRecordMapper.update(null, wrapper1);
        // 将progress修改为维修完成
        UpdateWrapper<MaintainApplication> wrapper2 = new UpdateWrapper<>();
        wrapper2.eq("id", maintainRecord.getApplicationId());
        wrapper2.setSql("progress = '维修完成'");
        int update = maintainApplicationMapper.update(null, wrapper2);
        return update;
    }

    @Override
    public Object getName(Long applicationId) {
        return maintainRecordMapper.getName(applicationId);
    }
}
