package com.example.mybatisplus.service;

import com.example.mybatisplus.model.domain.Checkin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
public interface CheckinService extends IService<Checkin> {

    boolean insert(Checkin checkin);

    void update(Checkin checkin);

    boolean checkinRemoveById(Long id);
}
