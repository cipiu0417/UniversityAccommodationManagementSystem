package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.SanitationRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
public interface SanitationRecordService extends IService<SanitationRecord> {

    List<Integer[]> weekNumber(Integer week);

    Page<SanitationRecord> sanitationRecordPageList(PageDTO pageDTO, SanitationRecord sanitationRecord);

    SanitationRecord sanitationRecordSelectById(Long id);

    boolean sanitationRemoveById(Long id);

    void insert(SanitationRecord sanitationRecord);

    void sanitationUpdate(SanitationRecord sanitationRecord);

    IPage<SanitationRecord> pageList(PageDTO pageDTO, User user);

    IPage<SanitationRecord> sanitationRecordSelectByRoomId(PageDTO pageDTO, Long roomId);

    List<Integer> selectScoresByWeek(Integer roomId, Integer week);
}
