package com.example.mybatisplus.service;

import com.example.mybatisplus.model.domain.Log;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-26
 */
public interface LogService extends IService<Log> {

    int insert(Log log);

    List<Log> getLog(Long appId);
}
