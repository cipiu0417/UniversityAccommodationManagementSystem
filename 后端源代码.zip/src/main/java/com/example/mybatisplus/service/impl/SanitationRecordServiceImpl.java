package com.example.mybatisplus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.SanitationRecord;
import com.example.mybatisplus.mapper.SanitationRecordMapper;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import com.example.mybatisplus.service.SanitationRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.collections4.QueueUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
@Service
public class SanitationRecordServiceImpl extends ServiceImpl<SanitationRecordMapper, SanitationRecord> implements SanitationRecordService {

    @Autowired
    private SanitationRecordMapper sanitationRecordMapper;

    @Override
    public Page<SanitationRecord> sanitationRecordPageList(PageDTO pageDTO, SanitationRecord sanitationRecord) {
        Page<SanitationRecord> page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        QueryWrapper<SanitationRecord> wrapper = new QueryWrapper<>();
        if(sanitationRecord.getRoomId()!=null){
            wrapper.eq("room_id",sanitationRecord.getRoomId());
        }
//        if(sanitationRecord.getDate()!=null){
//            wrapper.eq("date",sanitationRecord.getDate());
//        }
        if(StringUtils.isNotBlank(sanitationRecord.getPeopleSn())){
            wrapper.like("people_sn",sanitationRecord.getPeopleSn());
        }
        if(sanitationRecord.getScore()!=null){
            wrapper.eq("score",sanitationRecord.getScore());
        }
        wrapper.eq("is_deleted",0);
        Page<SanitationRecord> sanitationRecordPage = sanitationRecordMapper.selectPage(page,wrapper);

        return sanitationRecordPage;
    }

    @Override
    public SanitationRecord sanitationRecordSelectById(Long id) {
        SanitationRecord sanitationRecord = sanitationRecordMapper.selectById(id);
        return sanitationRecord;
    }

    @Override
    public boolean sanitationRemoveById(Long id) {
        return sanitationRecordMapper.myDeleteById(id);

    }

    @Override
    public void insert(SanitationRecord sanitationRecord) {
        sanitationRecordMapper.insert(sanitationRecord);
        return;
    }

    @Override
    public void sanitationUpdate(SanitationRecord sanitationRecord) {
        sanitationRecordMapper.updateById(sanitationRecord);
        return;
    }

    @Override
    public IPage<SanitationRecord> pageList(PageDTO pageDTO, User user) {
        Page page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        if(user.getRoleType()==1){
            //学生
            return sanitationRecordMapper.pageList1(page,user);
        }
        else if(user.getRoleType()==3){
            //宿管
            return sanitationRecordMapper.pageList3(page,user);
        }
        return new Page<>();
    }

    @Override
    public IPage<SanitationRecord> sanitationRecordSelectByRoomId(PageDTO pageDTO, Long roomId) {
        Page page = new Page<>(pageDTO.getPageNo(),pageDTO.getPageSize());
        return sanitationRecordMapper.selectByRoomId(page,roomId);
    }

    @Override
    public List<Integer> selectScoresByWeek(Integer roomId, Integer week) {
        QueryWrapper<SanitationRecord> wrapper = new QueryWrapper<>();
        wrapper.eq("week",week);
        wrapper.eq("room_id",roomId);
        SanitationRecord sanitationRecord = sanitationRecordMapper.selectOne(wrapper);
        List<Integer> scores = new ArrayList<>();
        scores.add(sanitationRecord.getRoomScore());
        scores.add(sanitationRecord.getBalconyScore());
        scores.add(sanitationRecord.getToiletScore());
        scores.add(sanitationRecord.getScore());
        return scores;
    }

    @Override
    public  List<Integer[]> weekNumber(Integer week){
        //创建返回的对象，每个等级的数量作为一个数组，全部分数作为一个集合
        //第一个数组是不及格、差、中等、良好、优秀的数量
        //第二个是房间卫生、阳台卫生、卫生间卫生、整体卫生的情况
        List<Integer[]> list = new ArrayList<>();
        //获得周数与传来的参数相同的卫生记录的数量
        //先返回周数相同的数据
        QueryWrapper<SanitationRecord> wrapper1 = new QueryWrapper<>();
        wrapper1.eq("week",week);
        //房间卫生分数大于等于90
        wrapper1.ge("room_score",90);
        List<SanitationRecord> list1 = sanitationRecordMapper.selectList(wrapper1);
        //符合条件的卫生记录的数量
        //int number = list1.size();
        Integer[] scores1 = new Integer[5];
        scores1[0] = list1.size();
        //房间卫生分数大于等于80小于90
        QueryWrapper<SanitationRecord> wrapper2 = new QueryWrapper<>();
        wrapper2.eq("week",week);
        wrapper2.ge("room_score",80);
        wrapper2.lt("room_score",90);
        List<SanitationRecord> list2 = sanitationRecordMapper.selectList(wrapper2);
        scores1[1] = list2.size();
        //房间卫生分数大于等于70小于80
        QueryWrapper<SanitationRecord> wrapper3 = new QueryWrapper<>();
        wrapper3.eq("week",week);
        wrapper3.ge("room_score",70);
        wrapper3.lt("room_score",80);
        List<SanitationRecord> list3 = sanitationRecordMapper.selectList(wrapper3);
        scores1[2] = list3.size();
        //房间卫生分数大于等于60小于70
        QueryWrapper<SanitationRecord> wrapper4 = new QueryWrapper<>();
        wrapper4.eq("week",week);
        wrapper4.ge("room_score",60);
        wrapper4.lt("room_score",70);
        List<SanitationRecord> list4 = sanitationRecordMapper.selectList(wrapper4);
        scores1[3] = list4.size();
        //房间卫生分数小于60
        QueryWrapper<SanitationRecord> wrapper5 = new QueryWrapper<>();
        wrapper5.eq("week",week);
        wrapper5.lt("room_score",60);
        List<SanitationRecord> list5 = sanitationRecordMapper.selectList(wrapper5);
        scores1[4] = list5.size();
        list.add(scores1);

        QueryWrapper<SanitationRecord> wrapper6 = new QueryWrapper<>();
        Integer[] scores2 = new Integer[5];
        wrapper6.eq("week",week);
        //阳台卫生分数大于等于90
        wrapper6.ge("balcony_score",90);
        List<SanitationRecord> list6 = sanitationRecordMapper.selectList(wrapper6);
        //符合条件的阳台卫生记录的数量
        scores2[0] = list6.size();
        //阳台卫生分数大于等于80小于90
        QueryWrapper<SanitationRecord> wrapper7 = new QueryWrapper<>();
        wrapper7.eq("week",week);
        wrapper7.ge("balcony_score",80);
        wrapper7.lt("balcony_score",90);
        List<SanitationRecord> list7 = sanitationRecordMapper.selectList(wrapper7);
        scores2[1] = list7.size();
        //阳台卫生分数大于等于70小于80
        QueryWrapper<SanitationRecord> wrapper8 = new QueryWrapper<>();
        wrapper8.eq("week",week);
        wrapper8.ge("balcony_score",70);
        wrapper8.lt("balcony_score",80);
        List<SanitationRecord> list8 = sanitationRecordMapper.selectList(wrapper8);
        scores2[2] = list8.size();
        //阳台卫生分数大于等于60小于70
        QueryWrapper<SanitationRecord> wrapper9 = new QueryWrapper<>();
        wrapper9.eq("week",week);
        wrapper9.ge("balcony_score",60);
        wrapper9.lt("balcony_score",70);
        List<SanitationRecord> list9 = sanitationRecordMapper.selectList(wrapper9);
        scores2[3] = list9.size();
        //房间卫生分数小于60
        QueryWrapper<SanitationRecord> wrapper10 = new QueryWrapper<>();
        wrapper10.eq("week",week);
        wrapper10.lt("balcony_score",60);
        List<SanitationRecord> list10 = sanitationRecordMapper.selectList(wrapper10);
        scores2[4] = list10.size();
        list.add(scores2);

        QueryWrapper<SanitationRecord> wrapper11 = new QueryWrapper<>();
        Integer[] scores3 = new Integer[5];
        wrapper11.eq("week",week);
        //卫生间卫生分数大于等于90
        wrapper11.ge("toilet_score",90);
        List<SanitationRecord> list11 = sanitationRecordMapper.selectList(wrapper11);
        //符合条件的卫生间卫生记录的数量
        scores3[0] = list11.size();
        //阳台卫生分数大于等于80小于90
        QueryWrapper<SanitationRecord> wrapper12 = new QueryWrapper<>();
        wrapper12.eq("week",week);
        wrapper12.ge("toilet_score",80);
        wrapper12.lt("toilet_score",90);
        List<SanitationRecord> list12 = sanitationRecordMapper.selectList(wrapper12);
        scores3[1] = list12.size();
        //卫生间卫生分数大于等于70小于80
        QueryWrapper<SanitationRecord> wrapper13 = new QueryWrapper<>();
        wrapper13.eq("week",week);
        wrapper13.ge("toilet_score",70);
        wrapper13.lt("toilet_score",80);
        List<SanitationRecord> list13 = sanitationRecordMapper.selectList(wrapper13);
        scores3[2] = list13.size();
        //卫生间卫生分数大于等于60小于70
        QueryWrapper<SanitationRecord> wrapper14 = new QueryWrapper<>();
        wrapper14.eq("week",week);
        wrapper14.ge("toilet_score",60);
        wrapper14.lt("toilet_score",70);
        List<SanitationRecord> list14 = sanitationRecordMapper.selectList(wrapper14);
        scores3[3] = list14.size();
        //房间卫生分数小于60
        QueryWrapper<SanitationRecord> wrapper15 = new QueryWrapper<>();
        wrapper15.eq("week",week);
        wrapper15.lt("toilet_score",60);
        List<SanitationRecord> list15 = sanitationRecordMapper.selectList(wrapper15);
        scores3[4] = list15.size();
        list.add(scores3);

        QueryWrapper<SanitationRecord> wrapper16 = new QueryWrapper<>();
        Integer[] scores4 = new Integer[5];
        wrapper16.eq("week",week);
        //总分数大于等于90
        wrapper16.ge("score",90);
        List<SanitationRecord> list16 = sanitationRecordMapper.selectList(wrapper16);
        //符合条件的总分卫生记录的数量
        scores4[0] = list16.size();
        //阳台卫生分数大于等于80小于90
        QueryWrapper<SanitationRecord> wrapper17 = new QueryWrapper<>();
        wrapper17.eq("week",week);
        wrapper17.ge("score",80);
        wrapper17.lt("score",90);
        List<SanitationRecord> list17 = sanitationRecordMapper.selectList(wrapper17);
        scores4[1] = list17.size();
        //总分数大于等于70小于80
        QueryWrapper<SanitationRecord> wrapper18 = new QueryWrapper<>();
        wrapper18.eq("week",week);
        wrapper18.ge("score",70);
        wrapper18.lt("score",80);
        List<SanitationRecord> list18 = sanitationRecordMapper.selectList(wrapper18);
        scores4[2] = list18.size();
        //总分数大于等于60小于70
        QueryWrapper<SanitationRecord> wrapper19 = new QueryWrapper<>();
        wrapper19.eq("week",week);
        wrapper19.ge("score",60);
        wrapper19.lt("score",70);
        List<SanitationRecord> list19 = sanitationRecordMapper.selectList(wrapper19);
        scores4[3] = list19.size();
        //总分数小于60
        QueryWrapper<SanitationRecord> wrapper20 = new QueryWrapper<>();
        wrapper20.eq("week",week);
        wrapper20.lt("score",60);
        List<SanitationRecord> list20 = sanitationRecordMapper.selectList(wrapper20);
        scores4[4] = list20.size();
        list.add(scores4);

        return list;
    }
}
