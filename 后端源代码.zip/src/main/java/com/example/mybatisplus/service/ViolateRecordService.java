package com.example.mybatisplus.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.domain.ViolateRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mybatisplus.model.dto.PageDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zt
 * @since 2023-06-28
 */
//@Service
public interface ViolateRecordService extends IService<ViolateRecord> {

    Page<ViolateRecord> violateRecordPageList(PageDTO pageDTO, ViolateRecord violateRecord);

    Object violateRecordSelectById(Long id);

    boolean violateRecordRemoveById(Long id);

    void insert(ViolateRecord violateRecord);

    void violateRecordUpdate(ViolateRecord violateRecord);

    IPage<ViolateRecord> pageList(PageDTO pageDTO, User user);

    IPage<ViolateRecord> violateRecordSelectByRoomId(PageDTO pageDTO,Long roomId);
}
