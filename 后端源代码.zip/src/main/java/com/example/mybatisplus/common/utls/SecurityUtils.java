package com.example.mybatisplus.common.utls;

import com.example.mybatisplus.model.domain.Admin;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.UserInfoDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SecurityUtils {
    /**
     * 获取当前用户
     *
     * @return
     */
    public static User getCurrentUserInfo() {
        User userInfo = SessionUtils.getCurrentUserInfo();
        //模拟登录
        if (userInfo == null) {
            userInfo = new User();
            userInfo.setSn("模拟");
            userInfo.setName("模拟");
        }

        return userInfo;
    }

    public static UserInfoDTO getUserInfo() {
        // 从session获取当前登录用户
        User userInfo = SessionUtils.getCurrentUserInfo();
        // 1、登录过了，能获取到值
        // 2、没登录，得到的肯定是null
        UserInfoDTO userInfoDTO = new UserInfoDTO();
        // 模拟登录（没登录过也假装登录，这个代码只能在开发当中用
        if (userInfo == null) {
            userInfo = new User();
            userInfoDTO.setId(1L);
            userInfoDTO.setName("模拟用户");
            // alter table admin add role_type bigint;在数据库中添加role_type属性
            // 对应到java，先在对应实体里加一个字段，再在xml文件中添加映射关系
            userInfoDTO.setUserType(2);
        }else{
            userInfoDTO.setId(userInfo.getId());
            userInfoDTO.setName(userInfo.getName());
            userInfoDTO.setUserType(userInfo.getRoleType());
            userInfoDTO.setSn(userInfo.getSn());
        }

        return userInfoDTO;
    }
}
