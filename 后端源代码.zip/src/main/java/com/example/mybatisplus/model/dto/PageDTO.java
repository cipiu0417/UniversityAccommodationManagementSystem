package com.example.mybatisplus.model.dto;

import lombok.Data;

@Data //创建getter和setter方法
public class PageDTO {
    private Integer pageNo = 1;
    private Integer pageSize = 10;
}
