package com.example.mybatisplus.model.dto;

import lombok.Data;

import java.util.List;

@Data
public class DeleteDTO {
    private List<Long> ids;
    private Long id;
}
