package com.example.mybatisplus.model.dto;

import lombok.Data;

@Data
public class UserInfoDTO {
    private Long id;
    private String name;
    private Integer userType;
    private String sn;
}
