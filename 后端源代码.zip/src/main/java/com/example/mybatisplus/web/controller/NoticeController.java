package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.dto.PageDTO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.NoticeService;
import com.example.mybatisplus.model.domain.Notice;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-28
 * @version v1.0
 */
@Controller
@RequestMapping("/api/notice")
public class NoticeController {

    private final Logger logger = LoggerFactory.getLogger( NoticeController.class );

    @Autowired
    private NoticeService noticeService;

    // 宿管发布公告
    @ResponseBody
    @PostMapping("saveNotice")
    public JsonResponse saveNotice(@RequestBody Notice notice) {
        return JsonResponse.success(noticeService.saveNotice(notice));
    }

    // 显示公告列表，包含通过关键字筛选功能
    @ResponseBody
    @GetMapping("pageList")
    public JsonResponse pageList(PageDTO pageDTO, Notice notice) {
        Page<Notice> page = noticeService.pageList(pageDTO, notice);
        return JsonResponse.success(page);
    }

    // 逻辑删除公告
    @ResponseBody
    @GetMapping("deleteById")
    public JsonResponse deleteById(Long id) {
        int b = noticeService.deleteById(id);
        return JsonResponse.success(b);
    }

    //根据Id返回content
    @ResponseBody
    @GetMapping("getContent")
    public JsonResponse getContent(Long id) {
        return JsonResponse.success(noticeService.getContent(id));
    }
}

