package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.domain.MaintainRecord;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.MaintainApplicationService;
import com.example.mybatisplus.model.domain.MaintainApplication;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-28
 * @version v1.0
 */
@Controller
@RequestMapping("/api/maintainApplication")
public class MaintainApplicationController {

    private final Logger logger = LoggerFactory.getLogger( MaintainApplicationController.class );

    @Autowired
    private MaintainApplicationService maintainApplicationService;

    // 提交维修申请
    @ResponseBody
    @PostMapping("save")
    public JsonResponse save(@RequestBody MaintainApplication maintainApplication) {
        maintainApplication.setProgress("待分配");
        int i = maintainApplicationService.insert(maintainApplication);
        return JsonResponse.success(i);
    }

    // 显示不同用户能看到的维修申请列表
    // 1、如果是学生，则用
    // select * from maintain_application where sn = user.sn
    // 2、如果是宿管，则
    // select * from maintain_application, room, checkin where
    // room.houseparent_sn = user.sn
    // and room.id = checkin.room_id
    // and checkin.sn = maintain_application.sn
    @GetMapping("pageList")
    @ResponseBody
    public JsonResponse pageList(PageDTO pageDTO, User user) {
        return JsonResponse.success(maintainApplicationService.pageList(pageDTO, user));
    }

    // 维修申请被分配维修员
    @ResponseBody
    @GetMapping("assignMaintainer")
    public JsonResponse assignMaintainer(Long id, String maintainerSn) {
        return JsonResponse.success(maintainApplicationService.assignMaintainer(id, maintainerSn));
    }

    // 维修员查看等待维修列表
    // 从maintain_record里选status为“等待维修”且maintainer_sn等于当前维修员sn的记录
    @ResponseBody
    @GetMapping("showList")
    public JsonResponse showList(PageDTO pageDTO, User user, String state) {
        return JsonResponse.success(maintainApplicationService.showList(pageDTO, user, state));
    }

    // 维修员查看历史维修列表
//    @ResponseBody
//    @GetMapping("showHistoryList")
//    public JsonResponse showHistoryList(PageDTO pageDTO, User user) {
//        return JsonResponse.success(maintainApplicationService.showHistoryList(pageDTO, user));
//    }

    // 维修员完成维修
    @ResponseBody
    @PostMapping("maintainComplete")
    public JsonResponse maintainComplete(@RequestBody MaintainApplication maintainApplication) {
        return JsonResponse.success(maintainApplicationService.maintainComplete(maintainApplication));
    }

    // 根据维修申请id返回维修员姓名
    @ResponseBody
    @GetMapping("getName")
    public JsonResponse getName(Long applicationId) {
        return JsonResponse.success(maintainApplicationService.getName(applicationId));
    }
}

