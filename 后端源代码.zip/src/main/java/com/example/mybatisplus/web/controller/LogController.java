package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.service.ApplicationService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.LogService;
import com.example.mybatisplus.model.domain.Log;

import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-26
 * @version v1.0
 */
@Controller
@RequestMapping("/api/log")
public class LogController {

    private final Logger logger = LoggerFactory.getLogger( LogController.class );

    @Autowired
    private LogService logService;
    private ApplicationService applicationService;

    // 添加审核记录
    @PostMapping("logInsert")
    @ResponseBody
    public JsonResponse logInsert(@RequestBody Log log) {
        int i = logService.insert(log);
        // 修改application的progress字段
        // 将progress更新为log的result和description
//        UpdateWrapper<Application> wrapper = new UpdateWrapper<>();
//        wrapper.eq("id", log.getAppId());
//        wrapper.set("progress", log.getResult() + ", " + log.getDescription());
//        applicationService.update(wrapper);
//        applicationService.stateChange(log);
        return JsonResponse.success(i);
    }

    // 获取审批已通过的条数
    @GetMapping("countLog")
    @ResponseBody
    public JsonResponse countLog(Log log) {
        QueryWrapper<Log> wrapper = new QueryWrapper<>();
        wrapper.eq("app_id", log.getAppId()).eq("result", 1);
        int count = logService.count(wrapper);
        return JsonResponse.success(count);
    }

    // 返回日志信息
    @GetMapping("getLog")
    @ResponseBody
    public JsonResponse getLog(Long appId) {
        List<Log> list = logService.getLog(appId);
        return JsonResponse.success(list);
    }
}

