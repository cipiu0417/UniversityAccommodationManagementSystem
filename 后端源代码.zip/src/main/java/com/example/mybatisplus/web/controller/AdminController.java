package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.mybatisplus.common.utls.SessionUtils;
import com.example.mybatisplus.mapper.AdminMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.AdminService;
import com.example.mybatisplus.model.domain.Admin;

import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author lxp
 * @since 2023-06-17
 * @version v1.0
 */
@Controller
@RequestMapping("/api/admin")
public class AdminController {

    private final Logger logger = LoggerFactory.getLogger( AdminController.class );

/*
    @Autowired
    private AdminMapper adminMapper;
*/
    @Autowired
    private AdminService adminService;

    @ResponseBody //把后端数据传到前端
    @GetMapping("xxxx") //设置前端的访问路径
    public JsonResponse xxx(Admin admin) {
        return JsonResponse.success(adminService.selectList(null));
    }

//    @ResponseBody //把后端数据传到前端
//    @PostMapping("login") //设置前端的访问路径
//    public JsonResponse login(@RequestBody Admin admin) {
//        Admin login = (Admin) adminService.login(admin);
//        // 把当前登录用户存进session
//        //SessionUtils.saveCurrentUserInfo(login);
//        //return JsonResponse.success(login);
//    }
}

