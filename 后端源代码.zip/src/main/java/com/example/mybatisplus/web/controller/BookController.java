package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.dto.DeleteDTO;
import com.example.mybatisplus.model.dto.PageDTO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.BookService;
import com.example.mybatisplus.model.domain.Book;

import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author lxp
 * @since 2023-06-17
 * @version v1.0
 */
@Controller
@RequestMapping("/api/book")
public class BookController {

    private final Logger logger = LoggerFactory.getLogger( BookController.class );

    @Autowired
    private BookService bookService;

    @RequestMapping(value = "bookList", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse getList() {
        List<Book> list = bookService.list();
        return JsonResponse.success(list);
    }

    // 两个实体当参数，只能使用get请求
    // post请求传递的json只能用一个对象接
    @RequestMapping(value = "pageList", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse getList(PageDTO pageDTO, Book book) {
        Page<Book> page = bookService.pageList(pageDTO, book);
        return JsonResponse.success(page);
    }

    // 根据id删除
    @RequestMapping(value = "removeById", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse removeById(Long id) {
        boolean b = bookService.removeById(id);
        return JsonResponse.success(b);
    }
//    @PostMapping("removeById")
//    @ResponseBody
//    public JsonResponse removeById(@RequestBody DeleteDTO deleteDTO) {
//        boolean b = bookService.removeById(deleteDTO.getId());
//        return JsonResponse.success(b);
//    }

    // 删除多本图书
    @PostMapping("removeByIds")
    @ResponseBody
    public JsonResponse removeByIds(@RequestBody DeleteDTO deleteDTO) {
        boolean b = bookService.removeByIds(deleteDTO.getIds());
        return JsonResponse.success(b);
    }

}

