package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.ViolateRecordService;
import com.example.mybatisplus.model.domain.ViolateRecord;

import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-28
 * @version v1.0
 */
@Controller
@RequestMapping("/api/violateRecord")
public class ViolateRecordController {

    private final Logger logger = LoggerFactory.getLogger( ViolateRecordController.class );

    @Autowired
    private ViolateRecordService violateRecordService;

    //分页显示违纪记录
    @GetMapping("violateRecordPageList")
    @ResponseBody
    public JsonResponse violateRecordPageList(PageDTO pageDTO,ViolateRecord violateRecord){
        Page<ViolateRecord> page = violateRecordService.violateRecordPageList(pageDTO,violateRecord);
        return JsonResponse.success(page);
    }

    //根据用户的身份显示对应的违纪记录  前端传回用户对象
    //1.学生type=1 学生只能看到自己所在宿舍的违纪记录
    //select * from user,checkin,violate_record where checkin.sn = #{user.sn}
    // and checkin.room_id = violate_record.room_id
    //2.辅导员type=2 辅导员可以看到自己学生的违纪记录
    //select * from user,checkin,violate_record
    // where user.counsellor_sn = #{user.sn}
    // and user.sn = checkin.sn
    // and violate_record.room_id = checkin.room_id
    // 3.宿管type=3 宿管可以看到自己管的所有学生的违纪记录
    //select * from user,violate_record
    // where violate_record.houseparent_sn = #{user.sn}
    @GetMapping("pageList")
    @ResponseBody
    public JsonResponse pageList(PageDTO pageDTO, User  user){
        return JsonResponse.success(violateRecordService.pageList(pageDTO,user));
    }


    //根据id查询违纪记录
    @GetMapping("violateRecordSelectById")
    @ResponseBody
    public JsonResponse violateRecordSelectById(Long id){
        return JsonResponse.success(violateRecordService.violateRecordSelectById(id));
    }

    //根据room_id查询违纪记录
    @GetMapping("violateRecordSelectByRoomId")
    @ResponseBody
    public JsonResponse violateRecordSelectByRoomId(PageDTO pageDTO,Long roomId){
        return JsonResponse.success(violateRecordService.violateRecordSelectByRoomId(pageDTO,roomId));
    }

    //根据id删除
    @GetMapping("violateRecordRemoveById")
    @ResponseBody
    public JsonResponse violateRecordRemoveById(Long id){
        boolean b = violateRecordService.violateRecordRemoveById(id);
        return JsonResponse.success(b);
    }

    //添加违纪记录
    @PostMapping("violateRecordInsert")
    @ResponseBody
    public JsonResponse violateRecordInsert(@RequestBody ViolateRecord violateRecord){
        violateRecordService.insert(violateRecord);
        return JsonResponse.success(null);
    }

    //修改违纪记录
    @PostMapping("violateRecordUpdate")
    @ResponseBody
    public JsonResponse violateRecordUpdate(@RequestBody ViolateRecord violateRecord){
        violateRecordService.violateRecordUpdate(violateRecord);
        return JsonResponse.success(null);
    }

    /**
    * 描述：根据Id 查询
    *
    */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse getById(@PathVariable("id") Long id)throws Exception {
        ViolateRecord  violateRecord =  violateRecordService.getById(id);
        return JsonResponse.success(violateRecord);
    }

    /**
    * 描述：根据Id删除
    *
    */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResponse deleteById(@PathVariable("id") Long id) throws Exception {
        violateRecordService.removeById(id);
        return JsonResponse.success(null);
    }


    /**
    * 描述：根据Id 更新
    *
    */
    @RequestMapping(value = "", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse updateViolateRecord(ViolateRecord  violateRecord) throws Exception {
        violateRecordService.updateById(violateRecord);
        return JsonResponse.success(null);
    }


    /**
    * 描述:创建ViolateRecord
    *
    */
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse create(ViolateRecord  violateRecord) throws Exception {
        violateRecordService.save(violateRecord);
        return JsonResponse.success(null);
    }
}

