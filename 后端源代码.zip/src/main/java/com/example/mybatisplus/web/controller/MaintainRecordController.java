package com.example.mybatisplus.web.controller;

import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.MaintainRecordService;
import com.example.mybatisplus.model.domain.MaintainRecord;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-28
 * @version v1.0
 */
@Controller
@RequestMapping("/api/maintainRecord")
public class MaintainRecordController {

    private final Logger logger = LoggerFactory.getLogger( MaintainRecordController.class );

    @Autowired
    private MaintainRecordService maintainRecordService;

    // 宿管分配维修员后就添加一条维修记录，并将maintain_application里的progress修改为“等待维修”
    // 将maintain_record里的status设置为“等待维修”
    @ResponseBody
    @PostMapping("saveRecord")
    public JsonResponse saveRecord(@RequestBody MaintainRecord maintainRecord) {
        return JsonResponse.success(maintainRecordService.saveRecord(maintainRecord));
    }

    // 维修员查看等待维修列表
    // 从maintain_record里选status为“等待维修”且maintainer_sn等于当前维修员sn的记录
    @ResponseBody
    @GetMapping("showList")
    public JsonResponse showList(PageDTO pageDTO, User user) {
        return JsonResponse.success(maintainRecordService.showList(pageDTO, user));
    }

    // 维修员查看历史维修列表
    @ResponseBody
    @GetMapping("showHistoryList")
    public JsonResponse showHistoryList(PageDTO pageDTO, User user) {
        return JsonResponse.success(maintainRecordService.showHistoryList(pageDTO, user));
    }

    // 维修员完成维修,修改status为维修完成，修改progress为维修完成
    @ResponseBody
    @PostMapping("maintainComplete")
    public JsonResponse maintainComplete(@RequestBody MaintainRecord maintainRecord) {
        return JsonResponse.success(maintainRecordService.maintainComplete(maintainRecord));
    }

    // 根据维修申请id返回维修员姓名
    @ResponseBody
    @GetMapping("getName")
    public JsonResponse getName(Long applicationId) {
        return JsonResponse.success(maintainRecordService.getName(applicationId));
    }
}

