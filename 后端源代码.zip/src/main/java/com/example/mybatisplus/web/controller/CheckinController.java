package com.example.mybatisplus.web.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.CheckinService;
import com.example.mybatisplus.model.domain.Checkin;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-26
 * @version v1.0
 */
@Controller
@RequestMapping("/api/checkin")
public class CheckinController {

    private final Logger logger = LoggerFactory.getLogger( CheckinController.class );

    @Autowired
    private CheckinService checkinService;

    //学生提交入住申请，插入对应的入住信息
    @PostMapping("checkinInsert")
    @ResponseBody
    public JsonResponse checkinInsert(@RequestBody Checkin checkin){
        boolean b = checkinService.insert(checkin);
        return JsonResponse.success(b);
    }

    //学生提交换宿申请，修改相应的信息
    @PostMapping("checkinUpdate")
    @ResponseBody
    public JsonResponse checkinUpdate(@RequestBody Checkin checkin){
        checkinService.update(checkin);
        return JsonResponse.success(null);
    }

    //学生提交退宿申请，删除对应的入住信息
    //根据id删除
    @GetMapping("checkinRemove")
    @ResponseBody
    public JsonResponse checkinRemove(Long id){
        //System.out.println(checkin.getId());
        boolean b = checkinService.checkinRemoveById(id);
        return JsonResponse.success(b);
    }

    /**
    * 描述：根据Id 查询
    *
    */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse getById(@PathVariable("id") Long id)throws Exception {
        Checkin  checkin =  checkinService.getById(id);
        return JsonResponse.success(checkin);
    }

    /**
    * 描述：根据Id删除
    *
    */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResponse deleteById(@PathVariable("id") Long id) throws Exception {
        checkinService.removeById(id);
        return JsonResponse.success(null);
    }


    /**
    * 描述：根据Id 更新
    *
    */
    @RequestMapping(value = "", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse updateCheckin(Checkin  checkin) throws Exception {
        checkinService.updateById(checkin);
        return JsonResponse.success(null);
    }


    /**
    * 描述:创建Checkin
    *
    */
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse create(Checkin  checkin) throws Exception {
        checkinService.save(checkin);
        return JsonResponse.success(null);
    }
}

