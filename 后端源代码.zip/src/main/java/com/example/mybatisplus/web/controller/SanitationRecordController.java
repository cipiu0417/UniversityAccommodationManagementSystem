package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.SanitationRecordService;
import com.example.mybatisplus.model.domain.SanitationRecord;

import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-28
 * @version v1.0
 */
@Controller
@RequestMapping("/api/sanitationRecord")
public class SanitationRecordController {

    private final Logger logger = LoggerFactory.getLogger( SanitationRecordController.class );

    @Autowired
    private SanitationRecordService sanitationRecordService;

    //分页显示卫生记录
    @GetMapping("sanitationRecordPageList")
    @ResponseBody
    public JsonResponse sanitationRecordPageList(PageDTO pageDTO,SanitationRecord sanitationRecord){
        Page<SanitationRecord> page = sanitationRecordService.sanitationRecordPageList(pageDTO,sanitationRecord);
        return JsonResponse.success(page);
    }

    //根据用户的身份显示对应的卫生记录
    //1.学生type=1 学生只能看到自己所在宿舍的卫生情况
    //select * from checkin,sanitation_record where checkin.sn = #{user.sn}
    // and checkin.room_id = violate_record.room_id
    // 2.宿管type=3 宿管可以看到自己管的所有宿舍的卫生记录
    //select * from sanitation_record
    // where sanitation_record.people_sn = #{user.sn}
    @GetMapping("pageList")
    @ResponseBody
    public JsonResponse pageList(PageDTO pageDTO, User user){
        return JsonResponse.success(sanitationRecordService.pageList(pageDTO,user));
    }

    //根据id查询
    @GetMapping("sanitationRecordSelectById")
    @ResponseBody
    public JsonResponse sanitationRecordSelectById(Long id){
        return JsonResponse.success(sanitationRecordService.sanitationRecordSelectById(id));
    }

    //根据room_id查询卫生记录
    @GetMapping("sanitationRecordSelectByRoomId")
    @ResponseBody
    public JsonResponse sanitationRecordSelectByRoomId(PageDTO pageDTO,Long roomId){
        return JsonResponse.success(sanitationRecordService.sanitationRecordSelectByRoomId(pageDTO,roomId));
    }

    //根据id删除
    @GetMapping("sanitationRecordRemoveById")
    @ResponseBody
    public JsonResponse sanitationRemoveById(Long id){
        boolean b = sanitationRecordService.sanitationRemoveById(id);
        return JsonResponse.success(b);
    }

    //添加新卫生记录
    @PostMapping("sanitationRecordInsert")
    @ResponseBody
    public JsonResponse sanitationInsert(@RequestBody SanitationRecord sanitationRecord){
        sanitationRecordService.insert(sanitationRecord);
        return JsonResponse.success(null);
    }

    //修改卫生记录
    @PostMapping("sanitationUpdate")
    @ResponseBody
    public JsonResponse sanitationUpdate(@RequestBody SanitationRecord sanitationRecord){
        sanitationRecordService.sanitationUpdate(sanitationRecord);
        return JsonResponse.success(null);
    }

    //根据传的week返回对应week的各分数的寝室数
    @GetMapping("weekNumber")
    @ResponseBody
    public  JsonResponse weekNumber(Integer week){

        return JsonResponse.success(sanitationRecordService.weekNumber(week));
    }

    //传room_id和week返回对应宿舍在该周的分数
    @GetMapping("selectScoresByWeek")
    @ResponseBody
    public JsonResponse selectScoresByWeek(Integer roomId,Integer week){
        return JsonResponse.success(sanitationRecordService.selectScoresByWeek(roomId,week));
    }


    /**
    * 描述：根据Id 查询
    *
    */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse getById(@PathVariable("id") Long id)throws Exception {
        SanitationRecord  sanitationRecord =  sanitationRecordService.getById(id);
        return JsonResponse.success(sanitationRecord);
    }

    /**
    * 描述：根据Id删除
    *
    */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResponse deleteById(@PathVariable("id") Long id) throws Exception {
        sanitationRecordService.removeById(id);
        return JsonResponse.success(null);
    }


    /**
    * 描述：根据Id 更新
    *
    */
    @RequestMapping(value = "", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse updateSanitationRecord(SanitationRecord  sanitationRecord) throws Exception {
        sanitationRecordService.updateById(sanitationRecord);
        return JsonResponse.success(null);
    }


    /**
    * 描述:创建SanitationRecord
    *
    */
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse create(SanitationRecord  sanitationRecord) throws Exception {
        sanitationRecordService.save(sanitationRecord);
        return JsonResponse.success(null);
    }
}

