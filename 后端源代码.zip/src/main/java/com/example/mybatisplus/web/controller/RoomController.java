package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.common.utls.ExcelUtil;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.dto.DeleteDTO;
import com.example.mybatisplus.model.dto.PageDTO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.RoomService;
import com.example.mybatisplus.model.domain.Room;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-25
 * @version v1.0
 */
@Controller
@RequestMapping("/api/room")
public class RoomController {

    private final Logger logger = LoggerFactory.getLogger( RoomController.class );

    @Autowired
    private RoomService roomService;

    // 分页显示房间列表
    @GetMapping("roomPageList")
    @ResponseBody
    public JsonResponse roomPageList(PageDTO pageDTO, Room room) {
        Page<Room> page = roomService.roomPageList(pageDTO, room);
        return JsonResponse.success(page);
    }

    // 根据id删除房间
    @GetMapping("roomRemoveById")
    @ResponseBody
    public JsonResponse roomRemoveById(Long id) {
        boolean b = roomService.roomRemoveById(id);
        return JsonResponse.success(b);
    }

    // 根据ids删除多个房间
    @PostMapping("roomRemoveByIds")
    @ResponseBody
    public JsonResponse roomRemoveByIds(@RequestBody DeleteDTO deleteDTO) {
        boolean b = roomService.roomRemoveByIds(deleteDTO.getIds());
        return JsonResponse.success(b);
    }

    //添加房间
    @PostMapping("roomInsert")
    @ResponseBody
    public JsonResponse roomInsert(@RequestBody Room room){
        roomService.insert(room);
        return JsonResponse.success(null);
    }

    //修改房源信息
    @PostMapping("roomUpdate")
    @ResponseBody
    public JsonResponse roomUpdate(@RequestBody Room room){
        roomService.update(room);
        return JsonResponse.success(null);
    }

    //导出房源信息
    //导出的本质是下载
    @PostMapping("exportRooms")
    @ResponseBody
    public void exportRooms(HttpServletResponse response,@RequestBody Room room) throws IOException {
        roomService.exportRooms(response,room);
    }

    //导出模板
    @PostMapping("exportTemp")
    @ResponseBody
    public void exportTemp(HttpServletResponse response) throws IOException {
        roomService.exportTemp(response);
    }

    //导入房源信息
    @PostMapping("importRooms")
    @ResponseBody
    public JsonResponse importRooms(MultipartFile file) {
        try {
            List<String[]> list = ExcelUtil.readExcel(file);
            return roomService.importRooms(list);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return JsonResponse.failure("程序发生异常，请联系管理员");
    }

    // 根据住宿申请表单内容查房间号
    @GetMapping("getRoomId")
    @ResponseBody
    public JsonResponse getRoomId(Application application) {
        return JsonResponse.success(roomService.getRoomId(application));
    }

    // 根据roomId返回room对象
    @GetMapping("getById")
    @ResponseBody
    public JsonResponse getById(Long roomId) {
        return JsonResponse.success(roomService.getById(roomId));
    }
}

