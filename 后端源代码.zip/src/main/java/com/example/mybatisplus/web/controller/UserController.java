package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.common.utls.ExcelUtil;
import com.example.mybatisplus.common.utls.SessionUtils;
import com.example.mybatisplus.model.domain.Application;
import com.example.mybatisplus.model.dto.DeleteDTO;
import com.example.mybatisplus.model.dto.PageDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.UserService;
import com.example.mybatisplus.model.domain.User;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-25
 * @version v1.0
 */
@Controller
@RequestMapping("/api/user")
public class UserController {

    private final Logger logger = LoggerFactory.getLogger( UserController.class );

    @Autowired
    private UserService userService;

    @ResponseBody //把后端数据传到前端
    @PostMapping("login") //设置前端的访问路径
    public JsonResponse login(@RequestBody User user) {
        User login = (User) userService.login(user);
        // 把当前登录用户存进session
        SessionUtils.saveCurrentUserInfo(login);
        return JsonResponse.success(login);
    }

    // 返回学生用户的辅导员工号（参数为学生学号）
    @ResponseBody
    @GetMapping("getCounsellorSn")
    public JsonResponse getCounsellorSn(String sn) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("sn", sn);
        return JsonResponse.success(userService.getOne(wrapper).getCounsellorSn());
    }

    // 返回学生用户的宿舍管理员工号（参数为学生学号）
    @ResponseBody
    @GetMapping("getHouseparentSn")
    public JsonResponse getHouseparentSn(String sn) {
        return JsonResponse.success(userService.getHouseparentSn(sn));
    }

    // 获取辅导员对应的全部学生申请列表（参数为辅导员工号）
    // 首先根据辅导员工号查询全部的学生学号
    // 再根据学生学号查询全部学生类型不是“维修申请”的申请
    // 返回的就是所有需要当前辅导员审核的申请
    @ResponseBody
    @GetMapping("counsellorGetApplicationList")
    public JsonResponse counsellorGetStudentList(String sn) {
        List<Application> list = userService.counsellorGetApplicationList(sn);
        return JsonResponse.success(list);
    }

    // 获取宿管对应的全部学生申请列表（参数为宿管工号）
    @ResponseBody
    @GetMapping("houseparentGetApplicationList")
    public JsonResponse houseparentGetApplicationList(String sn) {
        List<Application> list = userService.houseparentGetApplicationList(sn);
        return JsonResponse.success(list);
    }

    // 根据学生工号查姓名
    @ResponseBody
    @GetMapping("selectNameBySn")
    public JsonResponse selectNameBySn(String sn) {
        List<User> b = userService.selectNameBySn(sn);
        return JsonResponse.success(b);
    }

    // 获取全部维修人员名单
    @ResponseBody
    @GetMapping("getMaintainerList")
    public JsonResponse getMaintainerList() {
        List<User> list = userService.getMaintainerList();
        return JsonResponse.success(list);
    }


    //分页显示用户信息列表
    @GetMapping("userPageList")
    @ResponseBody
    public JsonResponse userPageList(PageDTO pageDTO,User user){
        Page<User> page = userService.userPageList(pageDTO,user);
        return JsonResponse.success(page);
    }

    //根据id删除用户
    @GetMapping("userRemoveById")
    @ResponseBody
    public JsonResponse userRemoveById(Long id){
        boolean b = userService.userRemoveById(id);
        return JsonResponse.success(b);
    }

    //批量删除
    @PostMapping("userRemoveByIds")
    @ResponseBody
    public JsonResponse userRemoveByIds(@RequestBody DeleteDTO deleteDTO){
        boolean b = userService.userRemoveByIds(deleteDTO.getIds());
        return JsonResponse.success(b);
    }

    //添加用户
    @PostMapping("userInsert")
    @ResponseBody
    public JsonResponse userInsert(@RequestBody User user){
        userService.insert(user);
        return JsonResponse.success(null);
    }

    //修改用户信息
    @PostMapping("userUpdate")
    @ResponseBody
    public JsonResponse userUpdate(@RequestBody User user){
        userService.update(user);
        return JsonResponse.success(null);
    }

    //学生信息导出模板
    @PostMapping("exportStudentTemp")
    @ResponseBody
    public void exportStudentTemp(HttpServletResponse response) throws IOException{
        userService.exportStudentTemp(response);
    }

    //宿管信息导出模板
    @PostMapping("exportHouseparentTemp")
    @ResponseBody
    public void exportHouseparentTemp(HttpServletResponse response) throws IOException{
        userService.exportHouseparentTemp(response);
    }

    //辅导员信息导出模板
    @PostMapping("exportCounsellorTemp")
    @ResponseBody
    public void exportCounsellorTemp(HttpServletResponse response) throws IOException{
        userService.exportCounsellorTemp(response);
    }

    //导入用户信息 包括学生、宿管、辅导员信息
    @PostMapping("importUsers")
    @ResponseBody
    public JsonResponse importUsers(MultipartFile file){
        try {
            List<String[]> list = ExcelUtil.readExcel(file);
            return userService.importUsers(list);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return JsonResponse.failure("程序发生异常，请联系管理员");
    }
}

