package com.example.mybatisplus.web.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mybatisplus.model.domain.Log;
import com.example.mybatisplus.model.domain.User;
import com.example.mybatisplus.model.dto.PageDTO;
//import com.example.mybatisplus.service.LogService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mybatisplus.common.JsonResponse;
import com.example.mybatisplus.service.ApplicationService;
import com.example.mybatisplus.model.domain.Application;


/**
 *
 *  前端控制器
 *
 *
 * @author zt
 * @since 2023-06-26
 * @version v1.0
 */
@Controller
@RequestMapping("/api/application")
public class ApplicationController {

    private final Logger logger = LoggerFactory.getLogger( ApplicationController.class );

    @Autowired
    private ApplicationService applicationService;

    // 发起申请并提交审核
    @PostMapping("save")
    @ResponseBody
    public JsonResponse save(@RequestBody Application application) {
        // 在申请表中添加记录，并将progress设置为待审核
        application.setProgress("待审核");
        // 内存地址 维修申请 x0123==x5466
        // application.getType() new String("维修申请") x5466
        // 维修申请 是不是等于 维修申请
//        if(StringUtils.equals(application.getType(),"维修申请")) {
//            application.setCounsellorChecked(true);
//        } else {
//            application.setCounsellorChecked(false);
//        }
        int i = applicationService.insert(application);
        return JsonResponse.success(i);
    }

    // 显示当前用户申请列表
//    @GetMapping("pageList")
//    @ResponseBody
//    public JsonResponse pageList(PageDTO pageDTO, Application application) {
//        Page<Application> page = applicationService.applicationPageList(pageDTO, application);
//        return JsonResponse.success(page);
//    }

    // 显示学生的申请列表，以及超级管理员能看到所有申请列表
    @GetMapping("pageList")
    @ResponseBody
    public JsonResponse pageList(PageDTO pageDTO, User user) {
        Page<Application> page = applicationService.pageList(pageDTO, user);
        return JsonResponse.success(page);
    }

    // 修改progress为审核通过
    @PostMapping("stateChange")
    @ResponseBody
    public JsonResponse stateChange(@RequestBody Application application) {
        boolean b = applicationService.stateChange(application);
        return JsonResponse.success(b);
    }

    // 修改progress为审核未通过
    @PostMapping("stateChangeNo")
    @ResponseBody
    public JsonResponse stateChangeNo(@RequestBody Application application) {
        boolean b = applicationService.stateChangeNo(application);
        return JsonResponse.success(b);
    }

    // 修改辅导员是否已审核
    @PostMapping("counsellorCheck")
    @ResponseBody
    public JsonResponse counsellorCheck(@RequestBody Application application) {
        boolean b = applicationService.counsellorCheck(application);
        return JsonResponse.success(b);
    }

    // 修改宿舍管理员是否已审核
    @PostMapping("houseparentCheck")
    @ResponseBody
    public JsonResponse houseparentCheck(@RequestBody Application application) {
        boolean b = applicationService.houseparentCheck(application);
        return JsonResponse.success(b);
    }
}

